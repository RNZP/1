require('dotenv').config()
const { decryptMedia } = require('@open-wa/wa-automate')

const moment = require('moment-timezone')
moment.tz.setDefault('Asia/Jakarta').locale('id')
const axios = require('axios')
const fetch = require('node-fetch')

const errorurl = 'https://steamuserimages-a.akamaihd.net/ugc/954087817129084207/5B7E46EE484181A676C02DFCAD48ECB1C74BC423/?imw=512&&ima=fit&impolicy=Letterbox&imcolor=%23000000&letterbox=false'

const { 
    removeBackgroundFromImageBase64
} = require('remove.bg')

const {
    exec
} = require('child_process')

const { 
    menuId, 
    cekResi, 
    urlShortener, 
    meme, 
    translate, 
    getLocationData,
    images,
    resep,
    rugapoi,
    rugaapi
} = require('./lib')

const { 
    msgFilter, 
    color, 
    processTime, 
    isUrl
} = require('./utils')

const { uploadImages } = require('./utils/fetcher')

const fs = require('fs-extra')
const banned = JSON.parse(fs.readFileSync('./settings/banned.json'))
let imagess = JSON.parse(fs.readFileSync('./lib/lock/imagess.json'))
const ban_spam = JSON.parse(fs.readFileSync('./settings/ban_spam.json'))
let whatanimee = JSON.parse(fs.readFileSync('./lib/lock/whatanime.json'))
let ship = JSON.parse(fs.readFileSync('./lib/lock/ship.json'))
let animee = JSON.parse(fs.readFileSync('./lib/lock/anime.json'))
let hentai = JSON.parse(fs.readFileSync('./lib/lock/hentai.json'))
let antilink = JSON.parse(fs.readFileSync('./lib/lock/antilink.json'))
const { 
    ownerNumber, 
    ownerNumbe,
    ownerNumb,
    ownerNum,
    groupLimit, 
    memberLimit,
    prefix
} = JSON.parse(fs.readFileSync('./settings/setting.json'))
const {
    apiNoBg
} = JSON.parse(fs.readFileSync('./settings/api.json'))

module.exports = HandleMsg = async (aruga, message) => {
    try {
        const { type, id, from, t, sender, isGroupMsg, chat, caption, chatId, isMedia, author, mimetype, quotedMsg, quotedMsgObj, mentionedJidList } = message
        let { body } = message
        var { name, formattedTitle } = chat
        let { pushname, verifiedName, formattedName } = sender
        pushname = pushname || verifiedName || formattedName // verifiedName is the name of someone who uses a business account
        const botNumber = await aruga.getHostNumber() + '@c.us'
        const groupId = isGroupMsg ? chat.groupMetadata.id : ''
        const groupAdmins = isGroupMsg ? await aruga.getGroupAdmins(groupId) : ''
        const isGroupAdmins = groupAdmins.includes(sender.id) || false
        const isBotGroupAdmins = groupAdmins.includes(botNumber) || false
        const isOwnerBot = ownerNumber == sender.id
        const isOwnerBo = ownerNumbe == sender.id
        const isOwnerB = ownerNumb == sender.id
        const isOwnert = ownerNum == sender.id
        const GroupLinkDetector = antilink.includes(chatId)
        const { isGroup, contact, groupMetadata } = chat;
        const stickermsg = message.type === 'sticker'
        const chats = (type === 'chat') ? body : (type === 'image' || type === 'video') ? caption : ''
        const isimages = isGroupMsg ? imagess.includes(chat.id) : false
        const iswhatanime = isGroupMsg ? whatanimee.includes(chat.id) : false
        const isanimes = isGroupMsg ? animee.includes(chat.id) : false
        const ishentai = isGroupMsg ? hentai.includes(chat.id) : false
        const isship = isGroupMsg ? ship.includes(chat.id) : false
        const validMessage = caption ? caption : body;
        const arguments = validMessage.trim().split(' ').slice(1)

        const isBanned = banned.includes(sender.id)
        const isban_spam = ban_spam.includes(sender.id)

        // Bot Prefix
        body = (type === 'chat' && body.startsWith(prefix)) ? body : ((type === 'image' && caption || type === 'video' && caption) && caption.startsWith(prefix)) ? caption : ''
        const command = body.slice(1).trim().split(/ +/).shift().toLowerCase()
        const arg = body.trim().substring(body.indexOf(' ') + 1)
        const args = body.trim().split(/ +/).slice(1)
        const isCmd = body.startsWith(prefix)
        const uaOverride = process.env.UserAgent
        const url = args.length !== 0 ? args[0] : ''
        const isQuotedImage = quotedMsg && quotedMsg.type === 'image'
	    const isQuotedVideo = quotedMsg && quotedMsg.type === 'video'

        // [BETA] Avoid Spam Message
        if (!isCmd) { return }
        if (isCmd && !isGroupMsg) { console.log(color('[EXEC]'), color(moment(t * 1000).format('DD/MM/YY HH:mm:ss'), 'yellow'), color(`${command} [${args.length}]`), 'from', color(pushname)) }
        if (isCmd && isGroupMsg) { console.log(color('[EXEC]'), color(moment(t * 1000).format('DD/MM/YY HH:mm:ss'), 'yellow'), color(`${command} [${args.length}]`), 'from', color(pushname), 'in', color(name || formattedTitle)) }

        // [BETA] Avoid Spam Message
        msgFilter.addFilter(from)

        if (isBanned) {
            if (args.length !== 1) return aruga.reply(from, 'لقد تم حظرك بسبب انتهاك الشروط يرجى التواصل مع الدعم', id)
            return console.log(color('[BAN]', 'red'), color(moment(t * 1000).format('DD/MM/YY HH:mm:ss'), 'yellow'), color(`${command} [${args.length}]`), 'from', color(pushname))
        }

        // [BETA] Avoid Spam Message
        msgFilter.addFilter(from)

        if (isban_spam) {
            if (args.length !== 1) return aruga.reply(from, 'لقد تم حظرك بسبب سبام يرجى التواصل مع الدعم', id)
            return console.log(color('[BAN_SPAM]', 'red'), color(moment(t * 1000).format('DD/MM/YY HH:mm:ss'), 'yellow'), color(`${command} [${args.length}]`), 'from', color(pushname))
        }

    //fitur anti link
      if (isGroupMsg && GroupLinkDetector && !isGroupAdmins && !isOwnerBot){
        if (chats.match(/(https:\/\/chat.whatsapp.com)/gi)) {
            const check = await aruga.inviteInfo(chats);
            if (!check) {
                return
            } else {
                aruga.reply(from, '*[كاشف الروابط]*\nيمنع نشر روابط القروبات في القروب سوف أطردك بسبب نشر الروابط باي باي :(', id).then(() => {
                    aruga.removeParticipant(groupId, sender.id)
                })
            }
        }
    }



        if (isGroupMsg && !isGroupAdmins && !isOwnerBot){
            if(stickermsg === true){
                if(isStickerMsg(serial)) return
                addStickerCount(serial)
            }
        }

        switch (command) {
        // Menu and TnC
        case 'speed':
        case 'ping':
            await aruga.sendText(from, `Ping!!!!\nSpeed: ${processTime(t, moment())} _Second_`)
            break
        case 'tnc':
            await aruga.sendText(from, menuId.textTnC())
            break
        case 'lock':
            if (!isGroupMsg) return aruga.reply(from, 'عذراً.لا يمكنك استخدام هذا الامر الا في القروبات!', id)
            if (!isGroupAdmins) return aruga.reply(from, 'عذراً ، لا يمكن استخدام هذا الأمر إلا من قبل مشرفين المجموعة!', id)
            await aruga.sendText(from, menuId.textlock())
            break
        case 'menu':
        case 'help':
            await aruga.sendText(from, menuId.textMenu(pushname))
            .then(() => ((isGroupMsg) && (isGroupAdmins)) ? aruga.sendText(from, `لطلب قائمة اوامر المشرفين : *menuadmin${prefix}*`) : null)
            break
        case 'menuadmin':
            if (!isGroupMsg) return aruga.reply(from, 'عذراً.لا يمكنك استخدام هذا الامر الا في القروبات!', id)
            if (!isGroupAdmins) return aruga.reply(from, 'عذراً ، لا يمكن استخدام هذا الأمر إلا من قبل مشرفين المجموعة!', id)
            await aruga.sendText(from, menuId.textAdmin())
            break
        case 'donate':
        case 'donasi':
            await aruga.sendText(from, menuId.textDonasi())
            break
        case 'ownerbot':
            await aruga.sendContact(from, ownerNumber)
            break
        case 'join':
            if (!isOwnerBot) return aruga.reply(from, 'عذراً . الامر خاص بمطور البوت!', id)
            if (args.length == 0) return aruga.reply(from, `Jika kalian ingin mengundang bot kegroup silahkan invite atau dengan\nketik ${prefix}join [link group]`, id)
            let linkgrup = body.slice(6)
            let islink = linkgrup.match(/(https:\/\/chat.whatsapp.com)/gi)
            let chekgrup = await aruga.inviteInfo(linkgrup)
            if (!islink) return aruga.reply(from, 'Maaf link group-nya salah! silahkan kirim link yang benar', id)
            if (isOwnerBot) {
                await aruga.joinGroupViaLink(linkgrup)
                      .then(async () => {
                          await aruga.sendText(from, 'تم دخول القروب!')
                          await aruga.sendText(chekgrup.id, `هاي\nانا 🔰 *يوري* 🔰 \nلطلب قائمة الاوامر اكتبhelp${prefix}`)
                      })
            } else {
                let cgrup = await aruga.getAllGroups()
                if (cgrup.size < memberLimit) return aruga.reply(from, `Sorry, Jika ingin menginvite minimal ${memberLimit} member`, id)
                await aruga.joinGroupViaLink(linkgrup)
                      .then(async () =>{
                          await aruga.reply(from, 'تم دخول القروب!', id)
                      })
                      .catch(() => {
                          aruga.reply(from, 'فشل!', id)
                      })
            }
            break

        // Sticker Creator
        case 'sticker':
        case 'stiker':
            if ((isMedia || isQuotedImage) && args.length === 0) {
                const encryptMedia = isQuotedImage ? quotedMsg : message
                const _mimetype = isQuotedImage ? quotedMsg.mimetype : mimetype
                const mediaData = await decryptMedia(encryptMedia, uaOverride)
                const imageBase64 = `data:${_mimetype};base64,${mediaData.toString('base64')}`
                aruga.sendImageAsSticker(from, imageBase64)
                .then(() => {
                    aruga.reply(from, 'Here\'s your sticker')
                    console.log(`Sticker Processed for ${processTime(t, moment())} Second`)
                })
            } else if (args[0] === 'nobg') {
                if (isMedia || isQuotedImage) {
                    try {
                    var mediaData = await decryptMedia(message, uaOverride)
                    var imageBase64 = `data:${mimetype};base64,${mediaData.toString('base64')}`
                    var base64img = imageBase64
                    var outFile = './media/noBg.png'
		            // kamu dapat mengambil api key dari website remove.bg dan ubahnya difolder settings/api.json
                    var result = await removeBackgroundFromImageBase64({ base64img, apiKey: apiNoBg, size: 'auto', type: 'auto', outFile })
                    await fs.writeFile(outFile, result.base64img)
                    await aruga.sendImageAsSticker(from, `data:${mimetype};base64,${result.base64img}`)
                    } catch(err) {
                    console.log(err)
	   	            await aruga.reply(from, 'عذرًا ، لقد وصل حد الاستخدام اليوم إلى الحد الأقصى', id)
                    }
                }
            } else if (args.length === 1) {
                if (!isUrl(url)) { await aruga.reply(from, 'عذرا ، الرابط الذي قدمته غير صالح.', id) }
                aruga.sendStickerfromUrl(from, url).then((r) => (!r && r !== undefined)
                    ? aruga.sendText(from, 'عذرا ، الرابط الذي أرسلته لا يحتوي على صورة.')
                    : aruga.reply(from, 'Ini StickerMu')).then(() => console.log(`Sticker Processed for ${processTime(t, moment())} Second`))
            } else {
                await aruga.reply(from, `إرسال الصور مع الامر او منشن الصورا`, id)
            }
            break
        
        case 'hentai':
            if (!isGroupMsg) return aruga.reply(from, 'عذرًا ، لا يمكن استخدام هذا الأمر إلا داخل المجموعات!', id)
            if (!ishentai) return aruga.reply(from, 'عذرا . الامر مقفل في القروب', id)
            const waifu = await axios.get('https://tobz-api.herokuapp.com/api/hentai?apikey=BotWeA')
            console.log(waifu.result)
            aruga.sendFileFromUrl(from, waifu.data.result, 'Waifu.jpg',)
            break
        case 'trap':
            if (!isGroupMsg) return aruga.reply(from, 'عذرًا ، لا يمكن استخدام هذا الأمر إلا داخل المجموعات!', id)
            if (!ishentai) return aruga.reply(from, 'عذرا . الامر مقفل في القروب', id)
            const trap = await axios.get('https://waifu.pics/api/nsfw/trap')
            console.log(trap.url)
            aruga.sendFileFromUrl(from, trap.data.url, 'Waifu.jpg',)
            break
        case 'hentai neko':
            if (!isGroupMsg) return aruga.reply(from, 'عذرًا ، لا يمكن استخدام هذا الأمر إلا داخل المجموعات!', id)
            if (!ishentai) return aruga.reply(from, 'عذرا . الامر مقفل في القروب', id)
            const hentaineko = await axios.get('https://waifu.pics/api/nsfw/neko')
            console.log(hentaineko.url)
            aruga.sendFileFromUrl(from, hentaineko.data.url, 'Waifu.jpg',)
            break
        case 'lgiu':
            if (!isGroupMsg) return aruga.reply(from, 'عذرًا ، لا يمكن استخدام هذا الأمر إلا داخل المجموعات!', id)
            if (!ishentai) return aruga.reply(from, 'عذرا . الامر مقفل في القروب', id)
            const lgiu = await axios.get('https://waifu.pics/api/nsfw/blowjob')
            console.log(lgiu.url)
            aruga.sendFileFromUrl(from, lgiu.data.url, 'lgiu.gif',)
            break
        case 'stickergif':
        case 'stikergif':
            if (isMedia || isQuotedVideo) {
                if (mimetype === 'video/mp4' && message.duration < 10 || mimetype === 'image/gif' && message.duration < 10) {
                    var mediaData = await decryptMedia(message, uaOverride)
                    aruga.reply(from, '[انتظر] قيد التقدم⏳ الرجاء الانتظار ± 1 دقيقة!', id)
                    var filename = `./media/stickergif.${mimetype.split('/')[1]}`
                    await fs.writeFileSync(filename, mediaData)
                    await exec(`gify ${filename} ./media/stickergf.gif --fps=30 --scale=240:240`, async function (error, stdout, stderr) {
                        var gif = await fs.readFileSync('./media/stickergf.gif', { encoding: "base64" })
                        await aruga.sendImageAsSticker(from, `data:image/gif;base64,${gif.toString('base64')}`)
                        .catch(() => {
                            aruga.reply(from, 'عذرا ، الملف كبير جدا!', id)
                        })
                    })
                  } else {
                    aruga.reply(from, `[❗] أرسل صورة gif مع شرح *stickergif${prefix}* بحد أقصى 10 ثوانٍ!`, id)
                   }
                } else {
		    aruga.reply(from, `[❗] أرسل صورة gif مع شرح *stickergif${prefix}*`, id)
	        }
            break
        case 'waifu':
            const waaifu = await axios.get('https://mhankbarbar.herokuapp.com/api/waifu')
            console.log(waaifu.image)
            aruga.sendFileFromUrl(from, waaifu.data.image, 'Waifu.jpg', `❤️ الاسم : ${waaifu.data.name}\n🎉️ الوصف : ${waaifu.data.desc}`, id)
            break 
        // case 'stikergiphy':
        // case 'stickergiphy':
        //     if (args.length !== 1) return aruga.reply(from, `عذرا ، تنسيق الرسالة خاطئ.\nKetik pesan dengan ${prefix}stickergiphy <link_giphy>`, id)
        //     const isGiphy = url.match(new RegExp(/https?:\/\/(www\.)?giphy.com/, 'gi'))
        //     const isMediaGiphy = url.match(new RegExp(/https?:\/\/media.giphy.com\/media/, 'gi'))
        //     if (isGiphy) {
        //         const getGiphyCode = url.match(new RegExp(/(\/|\-)(?:.(?!(\/|\-)))+$/, 'gi'))
        //         if (!getGiphyCode) { return aruga.reply(from, 'Gagal mengambil kode giphy', id) }
        //         const giphyCode = getGiphyCode[0].replace(/[-\/]/gi, '')
        //         const smallGifUrl = 'https://media.giphy.com/media/' + giphyCode + '/giphy-downsized.gif'
        //         aruga.sendGiphyAsSticker(from, smallGifUrl).then(() => {
        //             aruga.reply(from, 'Ini StickerMu')
        //             console.log(`Sticker Processed for ${processTime(t, moment())} Second`)
        //         }).catch((err) => console.log(err))
        //     } else if (isMediaGiphy) {
        //         const gifUrl = url.match(new RegExp(/(giphy|source).(gif|mp4)/, 'gi'))
        //         if (!gifUrl) { return aruga.reply(from, 'Gagal mengambil kode giphy', id) }
        //         const smallGifUrl = url.replace(gifUrl[0], 'giphy-downsized.gif')
        //         aruga.sendGiphyAsSticker(from, smallGifUrl)
        //         .then(() => {
        //             aruga.reply(from, 'Ini StickerMu')
        //             console.log(`Sticker Processed for ${processTime(t, moment())} Second`)
        //         })
        //         .catch(() => {
        //             aruga.reply(from, `Ada yang error!`, id)
        //         })
        //     } else {
        //         await aruga.reply(from, 'Maaf, command sticker giphy hanya bisa menggunakan link dari giphy.  [Giphy Only]', id)
        //     }
        //     break
        case 'meme':
            if ((isMedia || isQuotedImage) && args.length >= 2) {
                const top = arg.split('|')[0]
                const bottom = arg.split('|')[1]
                const encryptMedia = isQuotedImage ? quotedMsg : message
                const mediaData = await decryptMedia(encryptMedia, uaOverride)
                const getUrl = await uploadImages(mediaData, false)
                const ImageBase64 = await meme.custom(getUrl, top, bottom)
                aruga.sendFile(from, ImageBase64, 'image.png', '', null, true)
                    .then(() => {
                        aruga.reply(from, 'شكرا لك!',id)
                    })
                    .catch(() => {
                        aruga.reply(from, 'هناك خطأ ما!')
                    })
            } else {
                await aruga.reply(from, `Tidak ada gambar! Silahkan kirim gambar dengan caption ${prefix}meme <teks_atas> | <teks_bawah>\ncontoh: ${prefix}meme teks atas | teks bawah`, id)
            }
            break
        case 'quotemaker':
            const qmaker = body.trim().split('|')
            if (qmaker.length >= 3) {
                const quotes = qmaker[1]
                const author = qmaker[2]
                const theme = qmaker[3]
                aruga.reply(from, 'Proses kak..', id)
                try {
                    const hasilqmaker = await images.quote(quotes, author, theme)
                    aruga.sendFileFromUrl(from, `${hasilqmaker}`, '', 'Ini kak..', id)
                } catch {
                    aruga.reply('Yahh proses gagal, kakak isinya sudah benar belum?..', id)
                }
            } else {
                aruga.reply(from, `Pemakaian ${prefix}quotemaker |isi quote|author|theme\n\ncontoh: ${prefix}quotemaker |aku sayang kamu|-aruga|random\n\nuntuk theme nya pakai random ya kak..`)
            }
            break
            case 'nulis':
                if (args.length == 0) return aruga.reply(from, `Membuat bot menulis teks yang dikirim menjadi gambar\nPemakaian: ${prefix}nulis [teks]\n\ncontoh: ${prefix}nulis i love you 3000`, id)
                const nulisq = body.slice(7)
                const nulisp = await rugaapi.tulis(nulisq)
                await aruga.sendImage(from, `${nulisp}`, '', 'Nih...', id)
                .catch(() => {
                    aruga.reply(from, 'Ada yang Error!', id)
                })
                break

        //Islam Command
        // case 'listsurah':
        //     try {
        //         axios.get('https://raw.githubusercontent.com/ArugaZ/grabbed-results/main/islam/surah.json')
        //         .then((response) => {
        //             let hehex = '╔══✪〘 List Surah 〙✪══\n'
        //             for (let i = 0; i < response.data.data.length; i++) {
        //                 hehex += '╠➥ '
        //                 hehex += response.data.data[i].name.transliteration.id.toLowerCase() + '\n'
        //                     }
        //                 hehex += '╚═〘 🔰 *BOT ./MrG3P5* 🔰 〙'
        //             aruga.reply(from, hehex, id)
        //         })
        //     } catch(err) {
        //         aruga.reply(from, err, id)
        //     }
        //     break
        case 'infosurah':
            if (args.length == 0) return aruga.reply(from, `*_${prefix}infosurah <nama surah>_*\nMenampilkan informasi lengkap mengenai surah tertentu. Contoh penggunan: ${prefix}infosurah al-baqarah`, message.id)
                var responseh = await axios.get('https://raw.githubusercontent.com/ArugaZ/grabbed-results/main/islam/surah.json')
                var { data } = responseh.data
                var idx = data.findIndex(function(post, index) {
                  if((post.name.transliteration.id.toLowerCase() == args[0].toLowerCase())||(post.name.transliteration.en.toLowerCase() == args[0].toLowerCase()))
                    return true;
                });
                var pesan = ""
                pesan = pesan + "Nama : "+ data[idx].name.transliteration.id + "\n" + "Asma : " +data[idx].name.short+"\n"+"Arti : "+data[idx].name.translation.id+"\n"+"Jumlah ayat : "+data[idx].numberOfVerses+"\n"+"Nomor surah : "+data[idx].number+"\n"+"Jenis : "+data[idx].revelation.id+"\n"+"Keterangan : "+data[idx].tafsir.id
                aruga.reply(from, pesan, message.id)
              break
        case 'surah':
            if (args.length == 0) return aruga.reply(from, `*_${prefix}surah <nama surah> <ayat>_*\nMenampilkan ayat Al-Quran tertentu beserta terjemahannya dalam bahasa Indonesia. Contoh penggunaan : ${prefix}surah al-baqarah 1\n\n*_${prefix}surah <nama surah> <ayat> en/id_*\nMenampilkan ayat Al-Quran tertentu beserta terjemahannya dalam bahasa Inggris / Indonesia. Contoh penggunaan : ${prefix}surah al-baqarah 1 id`, message.id)
                var responseh = await axios.get('https://raw.githubusercontent.com/ArugaZ/grabbed-results/main/islam/surah.json')
                var { data } = responseh.data
                var idx = data.findIndex(function(post, index) {
                  if((post.name.transliteration.id.toLowerCase() == args[0].toLowerCase())||(post.name.transliteration.en.toLowerCase() == args[0].toLowerCase()))
                    return true;
                });
                nmr = data[idx].number
                if(!isNaN(nmr)) {
                  var responseh2 = await axios.get('https://api.quran.sutanlab.id/surah/'+nmr+"/"+args[1])
                  var {data} = responseh2.data
                  var last = function last(array, n) {
                    if (array == null) return void 0;
                    if (n == null) return array[array.length - 1];
                    return array.slice(Math.max(array.length - n, 0));
                  };
                  bhs = last(args)
                  pesan = ""
                  pesan = pesan + data.text.arab + "\n\n"
                  if(bhs == "en") {
                    pesan = pesan + data.translation.en
                  } else {
                    pesan = pesan + data.translation.id
                  }
                  pesan = pesan + "\n\n(Q.S. "+data.surah.name.transliteration.id+":"+args[1]+")"
                  aruga.reply(from, pesan, message.id)
                }
              break
        case 'tafsir':
            if (args.length == 0) return aruga.reply(from, `*_${prefix}tafsir <nama surah> <ayat>_*\nMenampilkan ayat Al-Quran tertentu beserta terjemahan dan tafsirnya dalam bahasa Indonesia. Contoh penggunaan : ${prefix}tafsir al-baqarah 1`, message.id)
                var responsh = await axios.get('https://raw.githubusercontent.com/ArugaZ/grabbed-results/main/islam/surah.json')
                var {data} = responsh.data
                var idx = data.findIndex(function(post, index) {
                  if((post.name.transliteration.id.toLowerCase() == args[0].toLowerCase())||(post.name.transliteration.en.toLowerCase() == args[0].toLowerCase()))
                    return true;
                });
                nmr = data[idx].number
                if(!isNaN(nmr)) {
                  var responsih = await axios.get('https://api.quran.sutanlab.id/surah/'+nmr+"/"+args[1])
                  var {data} = responsih.data
                  pesan = ""
                  pesan = pesan + "Tafsir Q.S. "+data.surah.name.transliteration.id+":"+args[1]+"\n\n"
                  pesan = pesan + data.text.arab + "\n\n"
                  pesan = pesan + "_" + data.translation.id + "_" + "\n\n" +data.tafsir.id.long
                  aruga.reply(from, pesan, message.id)
              }
              break
        case 'alaudio':
            if (args.length == 0) return aruga.reply(from, `*_${prefix}ALaudio <nama surah>_*\nMenampilkan tautan dari audio surah tertentu. Contoh penggunaan : ${prefix}ALaudio al-fatihah\n\n*_${prefix}ALaudio <nama surah> <ayat>_*\nMengirim audio surah dan ayat tertentu beserta terjemahannya dalam bahasa Indonesia. Contoh penggunaan : ${prefix}ALaudio al-fatihah 1\n\n*_${prefix}ALaudio <nama surah> <ayat> en_*\nMengirim audio surah dan ayat tertentu beserta terjemahannya dalam bahasa Inggris. Contoh penggunaan : ${prefix}ALaudio al-fatihah 1 en`, message.id)
              ayat = "ayat"
              bhs = ""
                var responseh = await axios.get('https://raw.githubusercontent.com/ArugaZ/grabbed-results/main/islam/surah.json')
                var surah = responseh.data
                var idx = surah.data.findIndex(function(post, index) {
                  if((post.name.transliteration.id.toLowerCase() == args[0].toLowerCase())||(post.name.transliteration.en.toLowerCase() == args[0].toLowerCase()))
                    return true;
                });
                nmr = surah.data[idx].number
                if(!isNaN(nmr)) {
                  if(args.length > 2) {
                    ayat = args[1]
                  }
                  if (args.length == 2) {
                    var last = function last(array, n) {
                      if (array == null) return void 0;
                      if (n == null) return array[array.length - 1];
                      return array.slice(Math.max(array.length - n, 0));
                    };
                    ayat = last(args)
                  } 
                  pesan = ""
                  if(isNaN(ayat)) {
                    var responsih2 = await axios.get('https://raw.githubusercontent.com/ArugaZ/grabbed-results/main/islam/surah/'+nmr+'.json')
                    var {name, name_translations, number_of_ayah, number_of_surah,  recitations} = responsih2.data
                    pesan = pesan + "Audio Quran Surah ke-"+number_of_surah+" "+name+" ("+name_translations.ar+") "+ "dengan jumlah "+ number_of_ayah+" ayat\n"
                    pesan = pesan + "Dilantunkan oleh "+recitations[0].name+" : "+recitations[0].audio_url+"\n"
                    pesan = pesan + "Dilantunkan oleh "+recitations[1].name+" : "+recitations[1].audio_url+"\n"
                    pesan = pesan + "Dilantunkan oleh "+recitations[2].name+" : "+recitations[2].audio_url+"\n"
                    aruga.reply(from, pesan, message.id)
                  } else {
                    var responsih2 = await axios.get('https://api.quran.sutanlab.id/surah/'+nmr+"/"+ayat)
                    var {data} = responsih2.data
                    var last = function last(array, n) {
                      if (array == null) return void 0;
                      if (n == null) return array[array.length - 1];
                      return array.slice(Math.max(array.length - n, 0));
                    };
                    bhs = last(args)
                    pesan = ""
                    pesan = pesan + data.text.arab + "\n\n"
                    if(bhs == "en") {
                      pesan = pesan + data.translation.en
                    } else {
                      pesan = pesan + data.translation.id
                    }
                    pesan = pesan + "\n\n(Q.S. "+data.surah.name.transliteration.id+":"+args[1]+")"
                    await aruga.sendFileFromUrl(from, data.audio.secondary[0])
                    await aruga.reply(from, pesan, message.id)
                  }
              }
              break
        case 'jsolat':
            if (args.length == 0) return aruga.reply(from, `Untuk melihat jadwal solat dari setiap daerah yang ada\nketik: ${prefix}jsolat [daerah]\n\nuntuk list daerah yang ada\nketik: ${prefix}daerah`, id)
            const solatx = body.slice(8)
            const solatj = await rugaapi.jadwaldaerah(solatx)
            await aruga.reply(from, solatj, id)
            .catch(() => {
                aruga.reply(from, 'Sudah input daerah yang ada dilist?', id)
            })
            break
        case 'daerah':
            const daerahq = await rugaapi.daerah()
            await aruga.reply(from, daerahq, id)
            .catch(() => {
                aruga.reply(from, 'هناك خطأ ما!', id)
            })
            break
        //Media
        case 'insta':
            if (args.length == 0) return aruga.reply(from, `Untuk mendownload gambar atau video dari instagram\nketik: ${prefix}instagram [link_ig]`, id)
            const instag = await rugaapi.insta(args[0])
            await aruga.sendFileFromUrl(from, instag, '', '', id)
            .catch(() => {
                aruga.reply(from, 'هناك خطأ ما!', id)
            })
            break
        case 'ytmp3':
            if (args.length == 0) return aruga.reply(from, `Untuk mendownload lagu dari youtube\nketik: ${prefix}ytmp3 [link_yt]`, id)
            rugaapi.ytmp3(args[0])
            .then(async(res) => {
				if (res.status == 'error') return aruga.sendFileFromUrl(from, `${res.linke}`, '', `${res.judul}`, id)
				if (res.status == 'filesize') return aruga.sendFileFromUrl(from, `${res.linke}`, '', `${res.judul}`, id)
				await aruga.sendFileFromUrl(from, `${res.thumb}`, '', `تم العثور عليه\n\nعنوان الفيديو: ${res.judul}\n\nحجم الملف الصوتي: ${res.size}\n\nرابط التميل المباشر ${res.linke}`, id)
			})
            break
        case 'ytmp4':
            if (args.length == 0) return aruga.reply(from, `Untuk mendownload video dari youtube\nketik: ${prefix}ytmp4 [link_yt]`)
            rugaapi.ytmp4(args[0])
            .then(async(res) => {
				if (res.status == 'error') return aruga.sendFileFromUrl(from, `${res.link}`, '', `${res.judul}`, id)
				if (res.status == 'filesize') return aruga.sendFileFromUrl(from, `${res.link}`, '', `${res.judul}`, id)
				await aruga.sendFileFromUrl(from, `${res.thumb}`, '', `Youtube ditemukan\n\nJudul: ${res.judul}\n\nUkuran: ${res.size}\n\nVideo sedang dikirim`, id)
				await aruga.sendFileFromUrl(from, `${res.link}`, '', '', id)
			})
            break
			
		//Primbon Menu
		case 'artinama':
			if (args.length == 0) return aruga.reply(from, `Untuk mengetahui artinama seseorang\nketik ${prefix}artinama namanya`, id)
            rugaapi.artinama(body.slice(10))
			.then(async(res) => {
				await aruga.reply(from, `Arti : ${res}`, id)
			})
			break
		case 'cekjodoh':
			if (args.length !== 2) return aruga.reply(from, `Untuk mengecek jodoh melalui nama\nketik: ${prefix}cekjodoh nama pasangan\n\ncontoh: ${prefix}cekjodoh aku kamu\n\nhanya bisa pakai nama panggilan (satu kata)`)
			rugaapi.cekjodoh(args[0],args[1])
			.then(async(res) => {
				await aruga.sendFileFromUrl(from, `${res.link}`, '', `${res.text}`, id)
			})
			break
			
        // Random Kata
        case 'fakta':
            fetch('https://raw.githubusercontent.com/ArugaZ/grabbed-results/main/random/faktaunix.txt')
            .then(res => res.text())
            .then(body => {
                let splitnix = body.split('\n')
                let randomnix = splitnix[Math.floor(Math.random() * splitnix.length)]
                aruga.reply(from, randomnix, id)
            })
            .catch(() => {
                aruga.reply(from, 'هناك خطأ ما!', id)
            })
            break
        case 'katabijak':
            fetch('https://raw.githubusercontent.com/ArugaZ/grabbed-results/main/random/katabijax.txt')
            .then(res => res.text())
            .then(body => {
                let splitbijak = body.split('\n')
                let randombijak = splitbijak[Math.floor(Math.random() * splitbijak.length)]
                aruga.reply(from, randombijak, id)
            })
            .catch(() => {
                aruga.reply(from, 'هناك خطأ ما!', id)
            })
            break
        case 'pantun':
            fetch('https://raw.githubusercontent.com/ArugaZ/grabbed-results/main/random/pantun.txt')
            .then(res => res.text())
            .then(body => {
                let splitpantun = body.split('\n')
                let randompantun = splitpantun[Math.floor(Math.random() * splitpantun.length)]
                aruga.reply(from, randompantun.replace(/aruga-line/g,"\n"), id)
            })
            .catch(() => {
                aruga.reply(from, 'هناك خطأ ما!', id)
            })
            break
        case 'quote':
            const quotex = await rugaapi.quote()
            await aruga.reply(from, quotex, id)
            .catch(() => {
                aruga.reply(from, 'هناك خطأ ما!', id)
            })
            break

        //Random Images
        case 'anime':
            if (!isGroupMsg) return aruga.reply(from, 'عذرًا ، لا يمكن استخدام هذا الأمر إلا داخل المجموعات!', id)
            if (!isanimes) return aruga.reply(from, 'عذرا . الامر مقفل في القروب لطلب قائمة lock \n\n#lock', id)
            if (args.length == 0) return aruga.reply(from, `Untuk menggunakan ${prefix}anime\nSilahkan ketik: ${prefix}anime [query]\nContoh: ${prefix}anime random\n\nquery yang tersedia:\nrandom, waifu, husbu, neko`, id)
            if (args[0] == 'random' || args[0] == 'waifu' || args[0] == 'husbu' || args[0] == 'neko') {
                fetch('https://raw.githubusercontent.com/ArugaZ/grabbed-results/main/random/anime/' + args[0] + '.txt')
                .then(res => res.text())
                .then(body => {
                    let randomnime = body.split('\n')
                    let randomnimex = randomnime[Math.floor(Math.random() * randomnime.length)]
                    aruga.sendFileFromUrl(from, randomnimex, '', 'Nee..', id)
                })
                .catch(() => {
                    aruga.reply(from, 'هناك خطأ ما!', id)
                })
            } else {
                aruga.reply(from, `Maaf query tidak tersedia. Silahkan ketik ${prefix}anime untuk melihat list query`)
            }
            break
        case 'stickertoimg':
        case 'theft':	
            if (quotedMsg && quotedMsg.type == 'sticker') {
                const mediaData = await decryptMedia(quotedMsg)
                aruga.reply(from, `من فضلك انتظر لحظة ...`, id)
                const imageBase64 = `data:${quotedMsg.mimetype};base64,${mediaData.toString('base64')}`
                await aruga.sendFile(from, imageBase64, 'imgsticker.jpg', 'تم . لقد تم تحويل الملصق الى صورا!', id)
                .then(() => {
                    console.log(`Sticker to Image Processed for ${processTime(t, moment())} Seconds`)
                })
        } else if (!quotedMsg) return aruga.reply(from, `Format salah, silahkan tag sticker yang ingin dijadikan gambar!`, id)
        break
        case 'xxxx':
            const diti = fs.readFileSync('./lib/husbu.json')
            const ditiJsin = JSON.parse(diti)
            const rindIndix = Math.floor(Math.random() * ditiJsin.length)
            const rindKiy = ditiJsin[rindIndix]
            aruga.sendFileFromUrl(from, rindKiy.image, 'Husbu.jpg', rindKiy.teks, id)
            break
        case 'kpop':
            if (args.length == 0) return aruga.reply(from, `Untuk menggunakan ${prefix}kpop\nSilahkan ketik: ${prefix}kpop [query]\nContoh: ${prefix}kpop bts\n\nquery yang tersedia:\nblackpink, exo, bts`, id)
            if (args[0] == 'blackpink' || args[0] == 'exo' || args[0] == 'bts') {
                fetch('https://raw.githubusercontent.com/ArugaZ/grabbed-results/main/random/kpop/' + args[0] + '.txt')
                .then(res => res.text())
                .then(body => {
                    let randomkpop = body.split('\n')
                    let randomkpopx = randomkpop[Math.floor(Math.random() * randomkpop.length)]
                    aruga.sendFileFromUrl(from, randomkpopx, '', 'Nee..', id)
                })
                .catch(() => {
                    aruga.reply(from, 'هناك خطأ ما!', id)
                })
            } else {
                aruga.reply(from, `Maaf query tidak tersedia. Silahkan ketik ${prefix}kpop untuk melihat list query`)
            }
            break
        case 'memes':
            const randmeme = await meme.random()
            aruga.sendFileFromUrl(from, randmeme, '', '', id)
            .catch(() => {
                aruga.reply(from, 'هناك خطأ ما!', id)
            })
            break
        
        // Search Any
        case 'images':
            if (!isGroupMsg) return aruga.reply(from, 'عذرًا ، لا يمكن استخدام هذا الأمر إلا داخل المجموعات!', id)
            if (!isimages) return aruga.reply(from, 'عذرا . الامر مقفل في القروب', id)
            if (args.length == 0) return aruga.reply(from, `للبحث عن الخلفيات في موقع pinterest اكتب [اسم الشخصية] images#`, id)
            const cariwall = body.slice(8)
            const hasilwall = await images.fdci(cariwall)
            aruga.sendFileFromUrl(from, hasilwall, '', '', id)
            .catch(() => {
                aruga.reply(from, 'Ada yang eror!', id)
            })
            break
        case 'resep':
            if (args.length == 0) return aruga.reply(from, `Untuk mencari resep makanan\nCaranya ketik: ${prefix}resep [search]\n\ncontoh: ${prefix}resep tahu`, id)
            const cariresep = body.slice(7)
            const hasilresep = await resep.resep(cariresep)
            aruga.reply(from, hasilresep + '\n\nIni kak resep makanannya..', id)
            .catch(() => {
                aruga.reply(from, 'هناك خطأ ما!', id)
            })
            break
            // case 'nekopoi':
            //     rugapoi.getLatest()
            //    .then((result) => {
            //        rugapoi.getVideo(result.link)
            //        .then((res) => {
            //            let heheq = '\n'
            //            for (let i = 0; i < res.links.length; i++) {
            //                heheq += `${res.links[i]}\n`
            //            }
            //            aruga.reply(from, `Title: ${res.title}\n\nLink:\n${heheq}\nmasih tester bntr :v`)
            //        })
            //    })
            //    .catch(() => {
            //        aruga.reply(from, 'Ada yang Error!', id)
            //    })
            //    break
        case 'stalkig':
            if (args.length == 0) return aruga.reply(from, `Untuk men-stalk akun instagram seseorang\nketik ${prefix}stalkig [username]\ncontoh: ${prefix}stalkig mrg3p5_id`, id)
            const igstalk = await rugaapi.stalkig(args[0])
            const igstalkpict = await rugaapi.stalkigpict(args[0])
            await aruga.sendFileFromUrl(from, igstalkpict, '', igstalk, id)
            .catch(() => {
                aruga.reply(from, 'هناك خطأ ما!', id)
            })
            break
        case 'wiki':
            if (args.length == 0) return aruga.reply(from, `للبحث عن كلمة من ويكيبيديا ،:\nأكتب: wiki${prefix} [kata]`, id)
            const wikip = body.slice(6)
            const wikis = await rugaapi.wiki(wikip)
            await aruga.reply(from, wikis, id)
            .catch(() => {
                aruga.reply(from, 'هناك خطأ ما!', id)
            })
            break
        case 'cuaca':
            if (args.length == 0) return aruga.reply(from, `لمعرفة حالة الطقس في منطقة ما \ n اكتب: cuaca${prefix} [Abha]`, id)
            const cuacaq = body.slice(7)
            const cuacap = await rugaapi.cuaca(cuacaq)
            await aruga.reply(from, cuacap, id)
            .catch(() => {
                aruga.reply(from, 'هناك خطأ ما!', id)
            })
            break
		case 'lirik':
			if (args.length == 0) return aruga.reply(from, `Untuk mencari lirik dari sebuah lagu\bketik: ${prefix}chord [judul_lagu]`, id)
			rugaapi.lirik(body.slice(7))
			.then(async (res) => {
				await aruga.reply(from, `Lirik Lagu: ${body.slice(7)}\n\n${res}`, id)
			})
			break
        case 'chord':
            if (args.length == 0) return aruga.reply(from, `Untuk mencari lirik dan chord dari sebuah lagu\bketik: ${prefix}chord [judul_lagu]`, id)
            const chordq = body.slice(7)
            const chordp = await rugaapi.chord(chordq)
            await aruga.reply(from, chordp, id)
            .catch(() => {
                aruga.reply(from, 'هناك خطأ ما!', id)
            })
            break
        case 'ss': //jika error silahkan buka file di folder settings/api.json dan ubah apiSS 'API-KEY' yang kalian dapat dari website https://apiflash.com/
            if (args.length == 0) return aruga.reply(from, `Membuat bot men-screenshot sebuah web\n\nPemakaian: ${prefix}ss [url]\n\ncontoh: ${prefix}ss http://google.com`, id)
            const scrinshit = await meme.ss(args[0])
            await aruga.sendFile(from, scrinshit, 'ss.jpg', 'cekrek', id)
            .catch(() => {
                aruga.reply(from, 'هناك خطأ ما!', id)
            })
            break
        case 'play'://silahkan kalian custom sendiri jika ada yang ingin diubah
            if (args.length == 0) return aruga.reply(from, `Untuk mencari lagu dari youtube\n\nPenggunaan: ${prefix}play judul lagu`, id)
            axios.get(`https://arugaytdl.herokuapp.com/search?q=${body.slice(6)}`)
            .then(async (res) => {
                await aruga.sendFileFromUrl(from, `${res.data[0].thumbnail}`, ``, `Lagu ditemukan\n\nJudul: ${res.data[0].title}\nDurasi: ${res.data[0].duration}detik\nUploaded: ${res.data[0].uploadDate}\nView: ${res.data[0].viewCount}\n\nsedang dikirim`, id)
				rugaapi.ytmp3(`https://youtu.be/${res.data[0].id}`)
				.then(async(res) => {
					if (res.status == 'error') return aruga.sendFileFromUrl(from, `${res.link}`, '', `${res.error}`)
					await aruga.sendFileFromUrl(from, `${res.thumb}`, '', `Lagu ditemukan\n\nJudul ${res.title}\n\nSabar lagi dikirim`, id)
					await aruga.sendFileFromUrl(from, `${res.link}`, '', '', id)
					.catch(() => {
						aruga.reply(from, `URL Ini ${args[0]} Sudah pernah di Download sebelumnya. URL akan di Reset setelah 1 Jam/60 Menit`, id)
					})
				})
            })
            .catch(() => {
                aruga.reply(from, 'Ada yang Error!', id)
            })
            break
            case 'whatanime':
                if (!isGroupMsg) return aruga.reply(from, 'عذرًا ، لا يمكن استخدام هذا الأمر إلا داخل المجموعات!', id)
                if (!iswhatanime) return aruga.reply(from, 'عذرا . الامر مقفل في القروب لطلب قائمةlock \n\n#lock', id)
                if (isMedia && type === 'image' || quotedMsg && quotedMsg.type === 'image') {
                    if (isMedia) {
                        var mediaData = await decryptMedia(message, uaOverride)
                    } else {
                        var mediaData = await decryptMedia(quotedMsg, uaOverride)
                    }
                    const fetch = require('node-fetch')
                    const imgBS4 = `data:${mimetype};base64,${mediaData.toString('base64')}`
                    aruga.reply(from, 'Searching....', id)
                    fetch('https://trace.moe/api/search', {
                        method: 'POST',
                        body: JSON.stringify({ image: imgBS4 }),
                        headers: { "Content-Type": "application/json" }
                    })
                    .then(respon => respon.json())
                    .then(resolt => {
                        if (resolt.docs && resolt.docs.length <= 0) {
                            aruga.reply(from, 'Maaf, saya tidak tau ini anime apa, pastikan gambar yang akan di Search tidak Buram/Kepotong', id)
                        }
                        const { is_adult, title, title_chinese, title_romaji, title_english, episode, similarity, filename, at, tokenthumb, anilist_id } = resolt.docs[0]
                        teks = ''
                        if (similarity < 0.92) {
                            teks = '*Saya memiliki keyakinan rendah dalam hal ini* :\n\n'
                        }
                        teks += `➸ *Title Japanese* : ${title}\n➸ *Title chinese* : ${title_chinese}\n➸ *Title Romaji* : ${title_romaji}\n➸ *Title English* : ${title_english}\n`
                        teks += `➸ *R-18?* : ${is_adult}\n`
                        teks += `➸ *Eps* : ${episode.toString()}\n`
                        teks += `➸ *Kesamaan* : ${(similarity * 100).toFixed(1)}%\n`
                        var video = `https://media.trace.moe/video/${anilist_id}/${encodeURIComponent(filename)}?t=${at}&token=${tokenthumb}`;
                        aruga.sendFileFromUrl(from, video, 'anime.mp4', teks, id).catch(() => {
                            aruga.reply(from, teks, id)
                        })
                    })
                    .catch(() => {
                        aruga.reply(from, 'هناك خطاء ما!', id)
                    })
                } else {
                    aruga.reply(from, `Maaf format salah\n\nSilahkan kirim foto dengan caption ${prefix}whatanime\n\nAtau reply foto dengan caption ${prefix}whatanime`, id)
                }
                break
            
        // Other Command
        case 'resi':
            if (args.length !== 2) return aruga.reply(from, `عذرا ، تنسيق الرسالة خاطئ.\nSilahkan ketik pesan dengan ${prefix}resi <kurir> <no_resi>\n\nKurir yang tersedia:\njne, pos, tiki, wahana, jnt, rpx, sap, sicepat, pcp, jet, dse, first, ninja, lion, idl, rex`, id)
            const kurirs = ['jne', 'pos', 'tiki', 'wahana', 'jnt', 'rpx', 'sap', 'sicepat', 'pcp', 'jet', 'dse', 'first', 'ninja', 'lion', 'idl', 'rex']
            if (!kurirs.includes(args[0])) return aruga.sendText(from, `Maaf, jenis ekspedisi pengiriman tidak didukung layanan ini hanya mendukung ekspedisi pengiriman ${kurirs.join(', ')} Tolong periksa kembali.`)
            console.log('Memeriksa No Resi', args[1], 'dengan ekspedisi', args[0])
            cekResi(args[0], args[1]).then((result) => aruga.sendText(from, result))
            break
        case 'tts':
            if (args.length == 0) return aruga.reply(from, `Mengubah teks menjadi sound (google voice)\nketik: ${prefix}tts <kode_bahasa> <teks>\ncontoh : ${prefix}tts id halo\nuntuk kode bahasa cek disini : https://anotepad.com/note/read/5xqahdy8`)
            const ttsGB = require('node-gtts')(args[0])
            const dataText = body.slice(8)
                if (dataText === '') return aruga.reply(from, 'ما هو النص على أي حال ..', id)
                try {
                    ttsGB.save('./media/tts.mp3', dataText, function () {
                    aruga.sendPtt(from, './media/tts.mp3', id)
                    })
                } catch (err) {
                    aruga.reply(from, err, id)
                }
            break
        case 'translate':
            if (args.length != 1) return aruga.reply(from, `عذرا ، تنسيق الرسالة خاطئ.\nSilahkan reply sebuah pesan dengan caption ${prefix}translate <kode_bahasa>\ncontoh ${prefix}translate id`, id)
            if (!quotedMsg) return aruga.reply(from, `عذرا ، تنسيق الرسالة خاطئ.\nSilahkan reply sebuah pesan dengan caption ${prefix}translate <kode_bahasa>\ncontoh ${prefix}translate id`, id)
            const quoteText = quotedMsg.type == 'chat' ? quotedMsg.body : quotedMsg.type == 'image' ? quotedMsg.caption : ''
            translate(quoteText, args[0])
                .then((result) => aruga.sendText(from, result))
                .catch(() => aruga.sendText(from, 'Error, Kode bahasa salah.'))
            break
		case 'covidindo':
			rugaapi.covidindo()
			.then(async (res) => {
				await aruga.reply(from, `${res}`, id)
			})
			break
        case 'ceklokasi':
            if (quotedMsg.type !== 'location') return aruga.reply(from, `عذرا ، تنسيق الرسالة خاطئ.\nKirimkan lokasi dan reply dengan caption ${prefix}ceklokasi`, id)
            console.log(`Request Status Zona Penyebaran Covid-19 (${quotedMsg.lat}, ${quotedMsg.lng}).`)
            const zoneStatus = await getLocationData(quotedMsg.lat, quotedMsg.lng)
            if (zoneStatus.kode !== 200) aruga.sendText(from, 'Maaf, Terjadi error ketika memeriksa lokasi yang anda kirim.')
            let datax = ''
            for (let i = 0; i < zoneStatus.data.length; i++) {
                const { zone, region } = zoneStatus.data[i]
                const _zone = zone == 'green' ? 'Hijau* (Aman) \n' : zone == 'yellow' ? 'Kuning* (Waspada) \n' : 'Merah* (Bahaya) \n'
                datax += `${i + 1}. Kel. *${region}* Berstatus *Zona ${_zone}`
            }
            const text = `*CEK LOKASI PENYEBARAN COVID-19*\nHasil pemeriksaan dari lokasi yang anda kirim adalah *${zoneStatus.status}* ${zoneStatus.optional}\n\nInformasi lokasi terdampak disekitar anda:\n${datax}`
            aruga.sendText(from, text)
            break
        case 'shortlink':
            if (args.length == 0) return aruga.reply(from, `ketik ${prefix}shortlink <url>`, id)
            if (!isUrl(args[0])) return aruga.reply(from, 'Maaf, url yang kamu kirim tidak valid.', id)
            const shortlink = await urlShortener(args[0])
            await aruga.sendText(from, shortlink)
            .catch(() => {
                aruga.reply(from, 'هناك خطأ ما!', id)
            })
            break
		case 'bapakfont':
			if (args.length == 0) return aruga.reply(from, `Mengubah kalimat menjadi alayyyyy\n\nketik ${prefix}bapakfont kalimat`, id)
			rugaapi.bapakfont(body.slice(11))
			.then(async(res) => {
				await aruga.reply(from, `${res}`, id)
			})
			break

        // Group Commands (group admin only)
	    case 'add':
            if (!isGroupMsg) return aruga.reply(from, 'عذرًا ، لا يمكن استخدام هذا الأمر إلا داخل المجموعات!', id)
            if (!isGroupAdmins) return aruga.reply(from, 'عذراً ، لا يمكن استخدام هذا الأمر إلا من قبل مشرفين المجموعة!', id)
            if (!isBotGroupAdmins) return aruga.reply(from, 'عذراً ، يرجى إضافة الروبوت كمسؤول مجموعة!', id)
	        if (args.length !== 1) return aruga.reply(from, `لأستخدام add${prefix}\nاكتب: add${prefix} <رقم الهاتف>\nمثال: ${prefix}add 9665044xxxxx`, id)
                try {
                    await aruga.addParticipant(from,`${args[0]}@c.us`)
		            .then(() => aruga.reply(from, 'هاي', id))
                } catch {
                    aruga.reply(from, 'لا يمكن إضافة المستخدم ', id)
                }
            break
        case 'kick':
            if (!isGroupMsg) return aruga.reply(from, 'عذرًا ، لا يمكن استخدام هذا الأمر إلا داخل المجموعات!', id)
            if (!isGroupAdmins) return aruga.reply(from, 'عذراً ، لا يمكن استخدام هذا الأمر إلا من قبل مشرفين المجموعة!', id)
            if (!isBotGroupAdmins) return aruga.reply(from, 'عذراً ، يرجى إضافة الروبوت كمسؤول مجموعة!', id)
            if (mentionedJidList.length === 0) return aruga.reply(from, 'عذرا ، تنسيق الرسالة خاطئ.\nلا أستطيع طرد نفسي اذا كنت تريد ان اطرد اكتب bye#', id)
            if (mentionedJidList[0] === botNumber) return await aruga.reply(from, 'عذرا ، تنسيق الرسالة خاطئ.\nTidak dapat mengeluarkan akun bot sendiri', id)
            await aruga.sendTextWithMentions(from, `سوف يتم طرد:\n${mentionedJidList.map(x => `@${x.replace('@c.us', '')}بأمر من المشرفين`).join('\n')}`)
            for (let i = 0; i < mentionedJidList.length; i++) {
                if (groupAdmins.includes(mentionedJidList[i])) return await aruga.sendText(from, 'عذراً ، لا يمكنك إزالة مسؤول المجموعة.')
                await aruga.removeParticipant(groupId, mentionedJidList[i])
            }
            break
            case 'add1':
            if (!isOwnerBot) return aruga.reply(from, 'عذراً . الامر خاص بمطور البوت!', id)
            if (!isBotGroupAdmins) return aruga.reply(from, 'عذراً ، يرجى إضافة الروبوت كمسؤول مجموعة!', id)
	        if (args.length !== 1) return aruga.reply(from, `لأستخدام add${prefix}\nاكتب: add${prefix} <رقم الهاتف>\nمثال: ${prefix}add 9665044xxxxx`, id)
                try {
                    await aruga.addParticipant(from,`${args[0]}@c.us`)
		            .then(() => aruga.reply(from, 'Hai selamat datang', id))
                } catch {
                    aruga.reply(from, 'لا يمكن إضافة المستخدم ', id)
                }
            break
            case 'kick1':
            if (!isOwnerBot) return aruga.reply(from, 'عذراً . الامر خاص بمطور البوت!', id)
            if (!isBotGroupAdmins) return aruga.reply(from, 'عذراً ، يرجى إضافة الروبوت كمسؤول مجموعة!', id)
            if (mentionedJidList.length === 0) return aruga.reply(from, 'عذرا ، تنسيق الرسالة خاطئ.\nلا أستطيع طرد نفسي اذا كنت تريد ان اطرد اكتب bye#', id)
            if (mentionedJidList[0] === botNumber) return await aruga.reply(from, 'عذرا ، تنسيق الرسالة خاطئ.\nTidak dapat mengeluarkan akun bot sendiri', id)
            await aruga.sendTextWithMentions(from, `سوف يتم طرد:\n${mentionedJidList.map(x => `@${x.replace('@c.us', '')}بأمر من المشرفين`).join('\n')}`)
            for (let i = 0; i < mentionedJidList.length; i++) {
                if (groupAdmins.includes(mentionedJidList[i])) return await aruga.sendText(from, 'عذراً ، لا يمكنك إزالة مسؤول المجموعة.')
                await aruga.removeParticipant(groupId, mentionedJidList[i])
            }
            break
        case 'promote':
            if (!isGroupMsg) return aruga.reply(from, 'عذرًا ، لا يمكن استخدام هذا الأمر إلا داخل المجموعات!', id)
            if (!isGroupAdmins) return aruga.reply(from, 'عذراً ، لا يمكن استخدام هذا الأمر إلا من قبل مشرفين المجموعة!', id)
            if (!isBotGroupAdmins) return aruga.reply(from, 'عذراً ، يرجى إضافة الروبوت كمسؤول مجموعة!', id)
            if (mentionedJidList.length !== 1) return aruga.reply(from, 'عذرًا ، يمكن رفع مستخدم واحد فقط', id)
            if (groupAdmins.includes(mentionedJidList[0])) return await aruga.reply(from, 'عذرا ، المستخدم هو بالفعل مشرف.', id)
            if (mentionedJidList[0] === botNumber) return await aruga.reply(from, 'عذرا ، تنسيق الرسالة خاطئ.\nعذراً . لا استطيع ترقية نفسي الى رتبة مشرف ', id)
            await aruga.promoteParticipant(groupId, mentionedJidList[0])
            await aruga.sendTextWithMentions(from, ` تم رفع رتبة العضو @${mentionedJidList[0].replace('@c.us', '')} الى مشرف.`)
            break
        case 'demote':
            if (!isGroupMsg) return aruga.reply(from, 'عذرًا ، لا يمكن استخدام هذا الأمر إلا داخل المجموعات!', id)
            if (!isGroupAdmins) return aruga.reply(from, 'عذراً ، لا يمكن استخدام هذا الأمر إلا من قبل مشرفين المجموعة!', id)
            if (!isBotGroupAdmins) return aruga.reply(from, 'عذراً ، يرجى إضافة الروبوت كمسؤول مجموعة!', id)
            if (mentionedJidList.length !== 1) return aruga.reply(from, 'عذرًا ، يمكن خفض مستخدم واحد فقط', id)
            if (!groupAdmins.includes(mentionedJidList[0])) return await aruga.reply(from, 'عذرا ، المستخدم ليس مسؤول حتى الآن.', id)
            if (mentionedJidList[0] === botNumber) return await aruga.reply(from, 'عذرا ، تنسيق الرسالة خاطئ.\nعذراً . لا استطيع اخفاض رتبة المشرف مني', id)
            await aruga.demoteParticipant(groupId, mentionedJidList[0])
            await aruga.sendTextWithMentions(from, `تم تخفيض رتبة المشرف الى عضو @${mentionedJidList[0].replace('@c.us', '')}.`)
            break
            case 'promote1':
            if (!isOwnerBot) return aruga.reply(from, 'عذراً . الامر خاص بمطور البوت!', id)
            if (!isBotGroupAdmins) return aruga.reply(from, 'عذراً ، يرجى إضافة الروبوت كمسؤول مجموعة!', id)
            if (mentionedJidList.length !== 1) return aruga.reply(from, 'عذرًا ، يمكن رفع مستخدم واحد فقط', id)
            if (groupAdmins.includes(mentionedJidList[0])) return await aruga.reply(from, 'عذرا ، المستخدم هو بالفعل مشرف.', id)
            if (mentionedJidList[0] === botNumber) return await aruga.reply(from, 'عذرا ، تنسيق الرسالة خاطئ.\nعذراً . لا استطيع ترقية نفسي الى رتبة مشرف ', id)
            await aruga.promoteParticipant(groupId, mentionedJidList[0])
            await aruga.sendTextWithMentions(from, ` تم رفع رتبة العضو @${mentionedJidList[0].replace('@c.us', '')} الى مشرف.`)
            break
            case 'demote1':
            if (!isOwnerBot) return aruga.reply(from, 'عذراً . الامر خاص بمطور البوت!', id)
            if (!isBotGroupAdmins) return aruga.reply(from, 'عذراً ، يرجى إضافة الروبوت كمسؤول مجموعة!', id)
            if (mentionedJidList.length !== 1) return aruga.reply(from, 'عذرًا ، يمكن خفض مستخدم واحد فقط', id)
            if (!groupAdmins.includes(mentionedJidList[0])) return await aruga.reply(from, 'عذرا ، المستخدم ليس مسؤول حتى الآن.', id)
            if (mentionedJidList[0] === botNumber) return await aruga.reply(from, 'عذرا ، تنسيق الرسالة خاطئ.\nعذراً . لا استطيع اخفاض رتبة المشرف مني', id)
            await aruga.demoteParticipant(groupId, mentionedJidList[0])
            await aruga.sendTextWithMentions(from, `تم تخفيض رتبة المشرف الى عضو @${mentionedJidList[0].replace('@c.us', '')}.`)
            break
        case 'bye':
            if (!isGroupMsg) return aruga.reply(from, 'عذرًا ، لا يمكن استخدام هذا الأمر إلا داخل المجموعات!', id)
            if (!isGroupAdmins) return aruga.reply(from, 'عذراً ، لا يمكن استخدام هذا الأمر إلا من قبل مشرفين المجموعة!', id)
            aruga.sendText(from, 'Good bye... ( ⇀‸↼‶ )').then(() => aruga.leaveGroup(groupId))
            break
        case 'leave':
            if (!isOwnerBot) return aruga.reply(from, 'عذراً . الامر خاص بمطور البوت!', id)
            if (!isGroupMsg) return aruga.reply(from, 'عذرًا ، لا يمكن استخدام هذا الأمر إلا داخل المجموعات!', id)
            aruga.sendText(from, 'Good bye... ( ⇀‸↼‶ )').then(() => aruga.leaveGroup(groupId))
            break
        case 'del':
            if (!isGroupAdmins) return aruga.reply(from, 'عذراً ، لا يمكن استخدام هذا الأمر إلا من قبل مشرفين المجموعة!', id)
            if (!quotedMsg) return aruga.reply(from, `Maaf, format pesan salah silahkan.\nReply pesan bot dengan caption ${prefix}del`, id)
            if (!quotedMsgObj.fromMe) return aruga.reply(from, `Maaf, format pesan salah silahkan.\nReply pesan bot dengan caption ${prefix}del`, id)
            aruga.deleteMessage(quotedMsgObj.chatId, quotedMsgObj.id, false)
            break
            case 'dele':
            if (!isOwnerBot) return aruga.reply(from, 'عذراً . الامر خاص بمطور البوت!', id)
            if (!quotedMsg) return aruga.reply(from, `Maaf, format pesan salah silahkan.\nReply pesan bot dengan caption ${prefix}del`, id)
            if (!quotedMsgObj.fromMe) return aruga.reply(from, `Maaf, format pesan salah silahkan.\nReply pesan bot dengan caption ${prefix}del`, id)
            aruga.deleteMessage(quotedMsgObj.chatId, quotedMsgObj.id, false)
            break
            case 'tagall':
                if (!isGroupAdmins) return aruga.reply(from, 'Baka!, only admins can use this command', message.id)
                const groupMem = await aruga.getGroupMembers(groupId)
                let hehe = `${body.slice(6)} - ${pushname} \n`
                for (let i = 0; i < groupMem.length; i++) {
                    hehe += '╠➥'
                    hehe += ` @${groupMem[i].id.replace(/@c.us/g, '')}\n`
                }
                hehe += '----------------------'
                await aruga.sendTextWithMentions(from, hehe)
                break
            
        case 'bots': {
            if (!isOwnerBot) return aruga.reply(from, 'عذراً . الامر خاص بمطور البوت!', id)
            const loadedMsg = await aruga.getAmountOfLoadedMessages()
            const chatIds = await aruga.getAllChatIds()
            const groups = await aruga.getAllGroups()
            aruga.sendText(from, `الحالة :\n- *${loadedMsg}* عدد الرسائل\n- *${groups.length}* عدد القروبات\n- *${chatIds.length - groups.length}* عدد المحادثات في الخاص\n- *${chatIds.length}* عدد الدردشات`)
            break
        }

        //Owner Group
        case 'kickall': //mengeluarkan semua member
        if (!isGroupMsg) return aruga.reply(from, 'عذرًا ، لا يمكن استخدام هذا الأمر إلا داخل المجموعات!', id)
        let isOwner = chat.groupMetadata.owner == sender.id
        if (!isOwner) return aruga.reply(from, 'عذرًا ، لا يمكن استخدام هذا الأمر إلا بواسطة مؤسس المجموعة!', id)
        if (!isBotGroupAdmins) return aruga.reply(from, 'عذراً ، يرجى إضافة الروبوت كمسؤول مجموعة!', id)
            const allMem = await aruga.getGroupMembers(groupId)
            for (let i = 0; i < allMem.length; i++) {
                if (groupAdmins.includes(allMem[i].id)) {

                } else {
                    await aruga.removeParticipant(groupId, allMem[i].id)
                }
            }
            aruga.reply(from, 'تم طرد الكل', id)
        break

        //Owner Bot    
        case 'ban':
            if (!isOwnerBot) return aruga.reply(from, 'عذراً . الامر خاص بمطور البوت!', id)
            if (args.length == 0) return aruga.reply(from, `Untuk banned seseorang agar tidak bisa menggunakan commands\n\nCaranya ketik: \n${prefix}ban add 628xx --untuk mengaktifkan\n${prefix}ban del 628xx --untuk nonaktifkan\n\ncara cepat ban banyak digrup ketik:\n${prefix}ban @tag @tag @tag`, id)
            if (args[0] == 'add') {
                banned.push(args[1]+'@c.us')
                fs.writeFileSync('./settings/banned.json', JSON.stringify(banned))
                aruga.reply(from, 'تم حظر المستخدم بنجاح!')
            } else
            if (args[0] == 'del') {
                let xnxx = banned.indexOf(args[1]+'@c.us')
                banned.splice(xnxx,1)
                fs.writeFileSync('./settings/banned.json', JSON.stringify(banned))
                aruga.reply(from, 'المستخدم غير محظور')
            } else {
             for (let i = 0; i < mentionedJidList.length; i++) {
                banned.push(mentionedJidList[i])
                fs.writeFileSync('./settings/banned.json', JSON.stringify(banned))
                aruga.reply(from, 'تم حظر المستخدم بنجاح!', id)
                }
            }
            break

            //Owner Bot    
        case 'ban_spam':
            if (!isOwnerBot) return aruga.reply(from, 'عذراً . الامر خاص بمطور البوت!', id)
            if (args.length == 0) return aruga.reply(from, `Untuk banned seseorang agar tidak bisa menggunakan commands\n\nCaranya ketik: \n${prefix}ban add 628xx --untuk mengaktifkan\n${prefix}ban del 628xx --untuk nonaktifkan\n\ncara cepat ban banyak digrup ketik:\n${prefix}ban @tag @tag @tag`, id)
            if (args[0] == 'add') {
                ban_spam.push(args[1]+'@c.us')
                fs.writeFileSync('./settings/ban_spam.json', JSON.stringify(ban_spam))
                aruga.reply(from, 'تم حظر المستخدم بنجاح!')
            } else
            if (args[0] == 'del') {
                let xnxx = ban_spam.indexOf(args[1]+'@c.us')
                ban_spam.splice(xnxx,1)
                fs.writeFileSync('./settings/ban_spam.json', JSON.stringify(ban_spam))
                aruga.reply(from, 'المستخدم غير محظور')
            } else {
             for (let i = 0; i < mentionedJidList.length; i++) {
                ban_spam.push(mentionedJidList[i])
                fs.writeFileSync('./settings/ban_spam.json', JSON.stringify(ban_spam))
                aruga.reply(from, 'تم حظر المستخدم بنجاح!', id)
                }
            }
            break

        //Owner Bot    
        case 'vip':
            if (!isOwnerBot) return aruga.reply(from, 'عذراً . الامر خاص بمطور البوت!', id)
            if (args.length == 0) return aruga.reply(from, `Untuk banned seseorang agar tidak bisa menggunakan commands\n\nCaranya ketik: \n${prefix}ban add 628xx --untuk mengaktifkan\n${prefix}ban del 628xx --untuk nonaktifkan\n\ncara cepat ban banyak digrup ketik:\n${prefix}ban @tag @tag @tag`, id)
            if (args[0] == 'add') {
                user.push(args[1]+'@c.us')
                fs.writeFileSync('./settings/user.json', JSON.stringify(user))
                aruga.reply(from, 'تم حظر المستخدم بنجاح!')
            } else
            if (args[0] == 'del') {
                let xnxx = user.indexOf(args[1]+'@c.us')
                user.splice(xnxx,1)
                fs.writeFileSync('./settings/user.json', JSON.stringify(user))
                aruga.reply(from, 'المستخدم غير محظور')
            } else {
             for (let i = 0; i < mentionedJidList.length; i++) {
                user.push(mentionedJidList[i])
                fs.writeFileSync('./settings/user.json', JSON.stringify(user))
                aruga.reply(from, 'تم ترقية المستخدم!', id)
                }
            }
            break
        case 'bc': //untuk broadcast atau promosi
            if (!isOwnerBot) return aruga.reply(from, 'عذراً . الامر خاص بمطور البوت!', id)
            if (args.length == 0) return aruga.reply(from, `يرجى كتابة النص الذي تريد تحويله الى كل المحادثات`)
            let msg = body.slice(4)
            const chatz = await aruga.getAllChatIds()
            for (let idk of chatz) {
                var cvk = await aruga.getChatById(idk)
                if (!cvk.isReadOnly) aruga.sendText(idk, `〘 *BOT ./MrG3P5 B C* 〙\n\n${msg}`)
                if (cvk.isReadOnly) aruga.sendText(idk, `〘 *BOT ./MrG3P5 B C* 〙\n\n${msg}`)
            }
            aruga.reply(from, 'تم!', id)
            break
        case 'leaveall': //mengeluarkan bot dari semua group serta menghapus chatnya
            if (!isOwnerBot) return aruga.reply(from, 'عذراً . الامر خاص بمطو�� البوت!', id)
            const allChatz = await aruga.getAllChatIds()
            const allGroupz = await aruga.getAllGroups()
            for (let gclist of allGroupz) {
                await aruga.sendText(gclist.contact.id, `البوت بيطلع من كل القروبات اذا تبغاه يرجع كلم مطور البوت باي باي`)
                await aruga.leaveGroup(gclist.contact.id)
                await aruga.deleteChat(gclist.contact.id)
            }
            aruga.reply(from, 'تم الخروج! من جميع القروبات', id)
            break
        case 'clearall': //menghapus seluruh pesan diakun bot
            if (!isOwnerBot) return aruga.reply(from, 'عذراً . الامر خاص بمطور البوت!', id)
            const allChatx = await aruga.getAllChats()
            for (let dchat of allChatx) {
                await aruga.deleteChat(dchat.id)
            }
            aruga.reply(from, 'تم حذف كل المحادثات!', id)
            break
            case 'grouplink':
            if (!isGroupAdmins) return aruga.reply(from, 'عذراً ، لا يمكن استخدام هذا الأمر إلا من قبل مشرفين المجموعة!', id)
            if (isGroupMsg) {
                const inviteLink = await aruga.getGroupInviteLink(groupId);
                aruga.sendLinkWithAutoPreview(from, inviteLink, `\nLink group *${name}* Gunakan *${prefix}revoke* untuk mereset Link group`)
                } else {
                    aruga.reply(from, 'Perintah ini hanya bisa di gunakan dalam group!', id)
                }
            break
            case 'admin':
                if (!isGroupMsg) return aruga.reply(from, '.', id)
                let mimin = ''
                for (let admon of groupAdmins) {
                    mimin += `➸ @${admon.replace(/@c.us/g, '')}\n` 
                }
                await aruga.sendTextWithMentions(from, mimin)
                break
        case "revoke":
	        if (!isGroupAdmins) return aruga.reply(from, 'عذراً . الامر مخصص لمشرفين القروب!', id)
                    if (isBotGroupAdmins) {
                        aruga
                            .revokeGroupInviteLink(from)
                            .then((res) => {
                                aruga.reply(from, `تم اعادة تعيين رابط الدعوة الخاص بالقروب اذا كنت تريد رابط الدعوة الجديد اكتب *grouplink${prefix}* untuk mendapatkan group invite link yang terbaru`, id);
                            })
                            .catch((err) => {
                                console.log(`[ERR] ${err}`);
                            });
                    }
                    break
                    case 'inu':
            const list = ["https://cdn.shibe.online/shibes/247d0ac978c9de9d9b66d72dbdc65f2dac64781d.jpg","https://cdn.shibe.online/shibes/1cf322acb7d74308995b04ea5eae7b520e0eae76.jpg","https://cdn.shibe.online/shibes/1ce955c3e49ae437dab68c09cf45297d68773adf.jpg","https://cdn.shibe.online/shibes/ec02bee661a797518d37098ab9ad0c02da0b05c3.jpg","https://cdn.shibe.online/shibes/1e6102253b51fbc116b887e3d3cde7b5c5083542.jpg","https://cdn.shibe.online/shibes/f0c07a7205d95577861eee382b4c8899ac620351.jpg","https://cdn.shibe.online/shibes/3eaf3b7427e2d375f09fc883f94fa8a6d4178a0a.jpg","https://cdn.shibe.online/shibes/c8b9fcfde23aee8d179c4c6f34d34fa41dfaffbf.jpg","https://cdn.shibe.online/shibes/55f298bc16017ed0aeae952031f0972b31c959cb.jpg","https://cdn.shibe.online/shibes/2d5dfe2b0170d5de6c8bc8a24b8ad72449fbf6f6.jpg","https://cdn.shibe.online/shibes/e9437de45e7cddd7d6c13299255e06f0f1d40918.jpg","https://cdn.shibe.online/shibes/6c32141a0d5d089971d99e51fd74207ff10751e7.jpg","https://cdn.shibe.online/shibes/028056c9f23ff40bc749a95cc7da7a4bb734e908.jpg","https://cdn.shibe.online/shibes/4fb0c8b74dbc7653e75ec1da597f0e7ac95fe788.jpg","https://cdn.shibe.online/shibes/125563d2ab4e520aaf27214483e765db9147dcb3.jpg","https://cdn.shibe.online/shibes/ea5258fad62cebe1fedcd8ec95776d6a9447698c.jpg","https://cdn.shibe.online/shibes/5ef2c83c2917e2f944910cb4a9a9b441d135f875.jpg","https://cdn.shibe.online/shibes/6d124364f02944300ae4f927b181733390edf64e.jpg","https://cdn.shibe.online/shibes/92213f0c406787acd4be252edb5e27c7e4f7a430.jpg","https://cdn.shibe.online/shibes/40fda0fd3d329be0d92dd7e436faa80db13c5017.jpg","https://cdn.shibe.online/shibes/e5c085fc427528fee7d4c3935ff4cd79af834a82.jpg","https://cdn.shibe.online/shibes/f83fa32c0da893163321b5cccab024172ddbade1.jpg","https://cdn.shibe.online/shibes/4aa2459b7f411919bf8df1991fa114e47b802957.jpg","https://cdn.shibe.online/shibes/2ef54e174f13e6aa21bb8be3c7aec2fdac6a442f.jpg","https://cdn.shibe.online/shibes/fa97547e670f23440608f333f8ec382a75ba5d94.jpg","https://cdn.shibe.online/shibes/fb1b7150ed8eb4ffa3b0e61ba47546dd6ee7d0dc.jpg","https://cdn.shibe.online/shibes/abf9fb41d914140a75d8bf8e05e4049e0a966c68.jpg","https://cdn.shibe.online/shibes/f63e3abe54c71cc0d0c567ebe8bce198589ae145.jpg","https://cdn.shibe.online/shibes/4c27b7b2395a5d051b00691cc4195ef286abf9e1.jpg","https://cdn.shibe.online/shibes/00df02e302eac0676bb03f41f4adf2b32418bac8.jpg","https://cdn.shibe.online/shibes/4deaac9baec39e8a93889a84257338ebb89eca50.jpg","https://cdn.shibe.online/shibes/199f8513d34901b0b20a33758e6ee2d768634ebb.jpg","https://cdn.shibe.online/shibes/f3efbf7a77e5797a72997869e8e2eaa9efcdceb5.jpg","https://cdn.shibe.online/shibes/39a20ccc9cdc17ea27f08643b019734453016e68.jpg","https://cdn.shibe.online/shibes/e67dea458b62cf3daa4b1e2b53a25405760af478.jpg","https://cdn.shibe.online/shibes/0a892f6554c18c8bcdab4ef7adec1387c76c6812.jpg","https://cdn.shibe.online/shibes/1b479987674c9b503f32e96e3a6aeca350a07ade.jpg","https://cdn.shibe.online/shibes/0c80fc00d82e09d593669d7cce9e273024ba7db9.jpg","https://cdn.shibe.online/shibes/bbc066183e87457b3143f71121fc9eebc40bf054.jpg","https://cdn.shibe.online/shibes/0932bf77f115057c7308ef70c3de1de7f8e7c646.jpg","https://cdn.shibe.online/shibes/9c87e6bb0f3dc938ce4c453eee176f24636440e0.jpg","https://cdn.shibe.online/shibes/0af1bcb0b13edf5e9b773e34e54dfceec8fa5849.jpg","https://cdn.shibe.online/shibes/32cf3f6eac4673d2e00f7360753c3f48ed53c650.jpg","https://cdn.shibe.online/shibes/af94d8eeb0f06a0fa06f090f404e3bbe86967949.jpg","https://cdn.shibe.online/shibes/4b55e826553b173c04c6f17aca8b0d2042d309fb.jpg","https://cdn.shibe.online/shibes/a0e53593393b6c724956f9abe0abb112f7506b7b.jpg","https://cdn.shibe.online/shibes/7eba25846f69b01ec04de1cae9fed4b45c203e87.jpg","https://cdn.shibe.online/shibes/fec6620d74bcb17b210e2cedca72547a332030d0.jpg","https://cdn.shibe.online/shibes/26cf6be03456a2609963d8fcf52cc3746fcb222c.jpg","https://cdn.shibe.online/shibes/c41b5da03ad74b08b7919afc6caf2dd345b3e591.jpg","https://cdn.shibe.online/shibes/7a9997f817ccdabac11d1f51fac563242658d654.jpg","https://cdn.shibe.online/shibes/7221241bad7da783c3c4d84cfedbeb21b9e4deea.jpg","https://cdn.shibe.online/shibes/283829584e6425421059c57d001c91b9dc86f33b.jpg","https://cdn.shibe.online/shibes/5145c9d3c3603c9e626585cce8cffdfcac081b31.jpg","https://cdn.shibe.online/shibes/b359c891e39994af83cf45738b28e499cb8ffe74.jpg","https://cdn.shibe.online/shibes/0b77f74a5d9afaa4b5094b28a6f3ee60efcb3874.jpg","https://cdn.shibe.online/shibes/adccfdf7d4d3332186c62ed8eb254a49b889c6f9.jpg","https://cdn.shibe.online/shibes/3aac69180f777512d5dabd33b09f531b7a845331.jpg","https://cdn.shibe.online/shibes/1d25e4f592db83039585fa480676687861498db8.jpg","https://cdn.shibe.online/shibes/d8349a2436420cf5a89a0010e91bf8dfbdd9d1cc.jpg","https://cdn.shibe.online/shibes/eb465ef1906dccd215e7a243b146c19e1af66c67.jpg","https://cdn.shibe.online/shibes/3d14e3c32863195869e7a8ba22229f457780008b.jpg","https://cdn.shibe.online/shibes/79cedc1a08302056f9819f39dcdf8eb4209551a3.jpg","https://cdn.shibe.online/shibes/4440aa827f88c04baa9c946f72fc688a34173581.jpg","https://cdn.shibe.online/shibes/94ea4a2d4b9cb852e9c1ff599f6a4acfa41a0c55.jpg","https://cdn.shibe.online/shibes/f4478196e441aef0ada61bbebe96ac9a573b2e5d.jpg","https://cdn.shibe.online/shibes/96d4db7c073526a35c626fc7518800586fd4ce67.jpg","https://cdn.shibe.online/shibes/196f3ed10ee98557328c7b5db98ac4a539224927.jpg","https://cdn.shibe.online/shibes/d12b07349029ca015d555849bcbd564d8b69fdbf.jpg","https://cdn.shibe.online/shibes/80fba84353000476400a9849da045611a590c79f.jpg","https://cdn.shibe.online/shibes/94cb90933e179375608c5c58b3d8658ef136ad3c.jpg","https://cdn.shibe.online/shibes/8447e67b5d622ef0593485316b0c87940a0ef435.jpg","https://cdn.shibe.online/shibes/c39a1d83ad44d2427fc8090298c1062d1d849f7e.jpg","https://cdn.shibe.online/shibes/6f38b9b5b8dbf187f6e3313d6e7583ec3b942472.jpg","https://cdn.shibe.online/shibes/81a2cbb9a91c6b1d55dcc702cd3f9cfd9a111cae.jpg","https://cdn.shibe.online/shibes/f1f6ed56c814bd939645138b8e195ff392dfd799.jpg","https://cdn.shibe.online/shibes/204a4c43cfad1cdc1b76cccb4b9a6dcb4a5246d8.jpg","https://cdn.shibe.online/shibes/9f34919b6154a88afc7d001c9d5f79b2e465806f.jpg","https://cdn.shibe.online/shibes/6f556a64a4885186331747c432c4ef4820620d14.jpg","https://cdn.shibe.online/shibes/bbd18ae7aaf976f745bc3dff46b49641313c26a9.jpg","https://cdn.shibe.online/shibes/6a2b286a28183267fca2200d7c677eba73b1217d.jpg","https://cdn.shibe.online/shibes/06767701966ed64fa7eff2d8d9e018e9f10487ee.jpg","https://cdn.shibe.online/shibes/7aafa4880b15b8f75d916b31485458b4a8d96815.jpg","https://cdn.shibe.online/shibes/b501169755bcf5c1eca874ab116a2802b6e51a2e.jpg","https://cdn.shibe.online/shibes/a8989bad101f35cf94213f17968c33c3031c16fc.jpg","https://cdn.shibe.online/shibes/f5d78feb3baa0835056f15ff9ced8e3c32bb07e8.jpg","https://cdn.shibe.online/shibes/75db0c76e86fbcf81d3946104c619a7950e62783.jpg","https://cdn.shibe.online/shibes/8ac387d1b252595bbd0723a1995f17405386b794.jpg","https://cdn.shibe.online/shibes/4379491ef4662faa178f791cc592b52653fb24b3.jpg","https://cdn.shibe.online/shibes/4caeee5f80add8c3db9990663a356e4eec12fc0a.jpg","https://cdn.shibe.online/shibes/99ef30ea8bb6064129da36e5673649e957cc76c0.jpg","https://cdn.shibe.online/shibes/aeac6a5b0a07a00fba0ba953af27734d2361fc10.jpg","https://cdn.shibe.online/shibes/9a217cfa377cc50dd8465d251731be05559b2142.jpg","https://cdn.shibe.online/shibes/65f6047d8e1d247af353532db018b08a928fd62a.jpg","https://cdn.shibe.online/shibes/fcead395cbf330b02978f9463ac125074ac87ab4.jpg","https://cdn.shibe.online/shibes/79451dc808a3a73f99c339f485c2bde833380af0.jpg","https://cdn.shibe.online/shibes/bedf90869797983017f764165a5d97a630b7054b.jpg","https://cdn.shibe.online/shibes/dd20e5801badd797513729a3645c502ae4629247.jpg","https://cdn.shibe.online/shibes/88361ee50b544cb1623cb259bcf07b9850183e65.jpg","https://cdn.shibe.online/shibes/0ebcfd98e8aa61c048968cb37f66a2b5d9d54d4b.jpg"]
            let kya = list[Math.floor(Math.random() * list.length)]
            aruga.sendFileFromUrl(from, kya, 'Dog.jpeg', 'Inu')
            break
        case 'mute':
			if (!isGroupMsg) return aruga.reply(from, 'عذرًا ، لا يمكن استخدام هذا الأمر إلا داخل المجموعات!', id)
            if (!isGroupAdmins) return aruga.reply(from, 'عذراً ، لا يمكن استخدام هذا الأمر إلا من قبل مشرفين المجموعة!', id)
            if (!isBotGroupAdmins) return aruga.reply(from, 'عذراً ، يرجى إضافة الروبوت كمسؤول مجموعة!', id)
			if (args.length !== 1) return aruga.reply(from, `لتغيير إعدادات الدردشة الجماعية بحيث يمكن للمسؤول فقط قفل الدردشة\n\nالاستعمالات:\n${prefix}mute on --تفعيل\n${prefix}mute off --تعطيل`, id)
            if (args[0] == 'on') {
				aruga.setGroupToAdminsOnly(groupId, true).then(() => aruga.sendText(from, 'تم قفل الشات فقط المشرفين يستطيعون التحدث !'))
			} else if (args[0] == 'off') {
				aruga.setGroupToAdminsOnly(groupId, false).then(() => aruga.sendText(from, 'تم فتح الشات كل الاعضاء يستطيعون التحدث!'))
			} else {
				aruga.reply(from, `لتغيير إعدادات الدردشة الجماعية بحيث يمكن للمسؤول فقط قفل الدردشة\n\nالاستعمالات:\n${prefix}mute on --تفعيل\n${prefix}mute off --تعطيل`, id)
			}
            break
        case 'icon':
			if (!isGroupMsg) return aruga.reply(from, 'عذرًا ، لا يمكن استخدام هذا الأمر إلا داخل المجموعات!', id)
            if (!isGroupAdmins) return aruga.reply(from, 'عذراً ، لا يمكن استخدام هذا الأمر إلا من قبل مشرفين المجموعة!', id)
            if (!isBotGroupAdmins) return aruga.reply(from, 'عذراً ، يرجى إضافة الروبوت كمسؤول مجموعة!', id)
			if (isMedia && type == 'image' || isQuotedImage) {
				const dataMedia = isQuotedImage ? quotedMsg : message
				const _mimetype = dataMedia.mimetype
				const mediaData = await decryptMedia(dataMedia, uaOverride)
				const imageBase64 = `data:${_mimetype};base64,${mediaData.toString('base64')}`
				await aruga.setGroupIcon(groupId, imageBase64)
			} else if (args.length === 1) {
				if (!isUrl(url)) { await aruga.reply(from, 'عذرا ، الرابط الذي قدمته غير صالح', id) }
				aruga.setGroupIconByUrl(groupId, url).then((r) => (!r && r !== undefined)
				? aruga.reply(from, 'عذرا ، الرابط الذي أرسلته لا يحتوي على صورة.', id)
				: aruga.reply(from, 'تم تغيير أيقونة المجموعة بنجاح', id))
			} else {
				aruga.reply(from, `يستخدم هذا الأمر لتغيير أيقونة / ملف تعريف القروب\n\n\nالاستعمالات\n1. الرجاء ارسال/الأمر مع الصورا او منشن الصورا icon${prefix}\n\n2. اكتب icon linkImage${prefix}`)
			}
            break
        case 'neko':
            q2 = Math.floor(Math.random() * 900) + 300;
            q3 = Math.floor(Math.random() * 900) + 300;
            aruga.sendFileFromUrl(from, 'http://placekitten.com/'+q3+'/'+q2, 'neko.png','Neko ')
            break
            case 'profile':
            var role = 'None'
              if (isGroupMsg) {
              if (!quotedMsg) {
              var baned = banned.includes(chat.id)
              var pic = await aruga.getProfilePicFromServer(author)
              var namae = pushname
              var sts = await aruga.getStatus(author)
              var adm = isGroupAdmins ? 'Yes' : 'No'
              const { status } = sts
               if (pic == undefined) {
               var pfp = errorurl 
               } else {
               var pfp = pic
               } 
             await aruga.sendFileFromUrl(from, pfp, 'pfp.jpg', `🔮 *Username: ${namae}*\n\n💾 *User Info: ${status}*\n\n*🚫 Ban: ${baned ? 'محظور' : 'غير محظور'}*\n\n✨️ *Role: ${role}*\n\n 👑️ *Admin: ${adm}*`)
             } else if (quotedMsg) {
             var qmid = quotedMsgObj.sender.id
             var baned = banned.includes(chat.id)
             var pic = await aruga.getProfilePicFromServer(qmid)
             var namae = quotedMsgObj.sender.formattedName
             var sts = await aruga.getStatus(qmid)
             var admgrp = await aruga.getGroupAdmins(from)
             var adm = admgrp.includes(qmid) ? 'Yes' : 'No'
             const { status } = sts
              if (pic == undefined) {
              var pfp = errorurl 
              } else {
              var pfp = pic
              } 
            await aruga.sendFileFromUrl(from, pfp, 'pfp.jpg', `🔖️ *Username: ${namae}*\n\n💌️ *User Info: ${status}*\n\n*💔️ Ban: ${baned ? 'محظور' : 'غير محظور'}*\n\n✨️ *Role: ${role}*\n\n 👑️ *Admin: ${adm}*`)
            }
            }
            break  
        case 'pokemon':
            q7 = Math.floor(Math.random() * 890) + 1;
            aruga.sendFileFromUrl(from, 'https://assets.pokemon.com/assets/cms2/img/pokedex/full/'+q7+'.png','Pokemon.png','Poke...', id)
            break
        case 'actanime':
            if (!isGroupMsg) return aruga.reply(from, 'عذرًا ، لا يمكن استخدام هذا الأمر إلا داخل المجموعات!', id)
            if (!isGroupAdmins) return aruga.reply(from, 'عذراً ، لا يمكن استخدام هذا الأمر إلا من قبل مشرفين المجموعة!', id)
			if (args.length !== 1) return aruga.reply(from, `Membuat BOT menyapa member yang baru join kedalam group chat!\n\nPenggunaan:\n${prefix}actanime on --aktifkan\n${prefix}actanime off --nonaktifkan`, id)
			if (args[0] == 'on') {
				animee.push(chatId)
				fs.writeFileSync('./lib/lock/anime.json', JSON.stringify(animee))
				aruga.reply(from, 'تم فتح امر anime', id)
			} else if (args[0] == 'off') {
				let xporn = animee.indexOf(chatId)
				animee.splice(xporn, 1)
				fs.writeFileSync('./lib/lock/anime.json', JSON.stringify(animee))
				aruga.reply(from, 'تم قفل امر anime', id)
			} else {
				aruga.reply(from, `Membuat BOT menyapa member yang baru join kedalam group chat!\n\nPenggunaan:\n${prefix}actanime on --aktifkan\n${prefix}actanime off --nonaktifkan`, id)
			}
			break
            case 'ship':
            if (!isship) return aruga.reply(from, 'عذرا . الامر مقفل في القروب', id)
            arge = body.trim().split(' ')
            const per = Math.floor(Math.random() * 100)

if (per < 25) { 
var sentence = `${per}% أسوأ من المتوسط ♦️`
} else if (per < 50) {
var sentence = `${per}% لا أعرف كيف أشعر حيال ذلك ❇️` 
} else if (per < 75) {
var sentence = `${per}% جيد حسب ما أعتقد ... ⭐️` 
} else if (per < 90) {
var sentence = `${per}% مبرووووك🤩️` 
} else {
var sentence = `${per}% لا يصدق! أنتما الاثنان ستكونان زوجين رائعين 😍️` 
}

var shiptext = `❣️ *نسبة التوافق...*

---------------------------------
    *${arge[1]}  x  ${arge[2]}*
---------------------------------

${sentence}`
        await aruga.sendTextWithMentions(from, shiptext)
        break
        case 'flip':
            const side = Math.floor(Math.random() * 2) + 1
            if (side == 1) {
                aruga.sendStickerfromUrl(from, 'https://i.ibb.co/LJjkVK5/heads.png')
            } else {
                aruga.sendStickerfromUrl(from, 'https://i.ibb.co/wNnZ4QD/tails.png')
            }
            break
            case 'actimages':
            if (!isGroupMsg) return aruga.reply(from, 'عذرًا ، لا يمكن استخدام هذا الأمر إلا داخل المجموعات!', id)
            if (!isGroupAdmins) return aruga.reply(from, 'عذراً ، لا يمكن استخدام هذا الأمر إلا من قبل مشرفين المجموعة!', id)
			if (args.length !== 1) return aruga.reply(from, `Membuat BOT menyapa member yang baru join kedalam group chat!\n\nPenggunaan:\n${prefix}actimagess on --aktifkan\n${prefix}actimagess off --nonaktifkan`, id)
			if (args[0] == 'on') {
				imagess.push(chatId)
				fs.writeFileSync('./lib/lock/imagess.json', JSON.stringify(imagess))
				aruga.reply(from, 'تم فتح امر images', id)
			} else if (args[0] == 'off') {
				let xporn = imagess.indexOf(chatId)
				imagess.splice(xporn, 1)
				fs.writeFileSync('./lib/lock/imagess.json', JSON.stringify(imagess))
				aruga.reply(from, 'تم قفل امر images', id)
			} else {
				aruga.reply(from, `Membuat BOT menyapa member yang baru join kedalam group chat!\n\nPenggunaan:\n${prefix}actimagess on --aktifkan\n${prefix}actimagess off --nonaktifkan`, id)
			}
            break
        case "":
            if (aruga.reply(from, 'أتقصد : help#', id))
            break
        case 'info' :
            if (!isGroupMsg) return aruga.reply(from, 'عذرًا ، لا يمكن استخدام هذا الأمر إلا داخل المجموعات!', id)
            var totalMem = chat.groupMetadata.participants.length
            var desc = chat.groupMetadata.desc
            var groupname = name
            var imagese = imagess.includes(chat.id)
            var whatanime = whatanimee.includes(chat.id)
            var hentaii = hentai.includes(chat.id)
            var anime = animee.includes(chat.id)
            var shipi = ship.includes(chat.id)
            var grouppic = await aruga.getProfilePicFromServer(chat.id)
            if (grouppic == undefined) {
                 var pfp = errorurl
            } else {
                 var pfp = grouppic 
            }
            await aruga.sendFileFromUrl(from, pfp, 'group.png', `         *「🏠 معلومات القروب 」*\n
*➸ 📚اسم القروب* : *${groupname}* \n
*➸ 👤عدد الأعضاء : ${totalMem}* \n
*「 📚الأوامر المقفله 」*
*➸ #images🖼️ : ${imagese ? 'مفعل' : 'مقفل'}* \n
*➸ #anime☺️ : ${anime ? 'مفعل' : 'مقفل'}* \n
*➸ #whatanime🌐 : ${whatanime ? 'مفعل' : 'مقفل'}* \n
*➸ #hentai🔞 : ${hentaii ? 'مفعل' : 'مقفل'}* \n
*➸ #ship💞 : ${shipi ? 'مفعل' : 'مقفل'}* \n
*➸ 🏠وصف القروب*
${desc}`)
            break
        case 'actwhatanime':
            if (!isGroupMsg) return aruga.reply(from, 'عذرًا ، لا يمكن استخدام هذا الأمر إلا داخل المجموعات!', id)
            if (!isGroupAdmins) return aruga.reply(from, 'عذراً ، لا يمكن استخدام هذا الأمر إلا من قبل مشرفين المجموعة!', id)
			if (args.length !== 1) return aruga.reply(from, `Membuat BOT menyapa member yang baru join kedalam group chat!\n\nPenggunaan:\n${prefix}actwhatanime on --aktifkan\n${prefix}actwhatanime off --nonaktifkan`, id)
			if (args[0] == 'on') {
				whatanimee.push(chatId)
				fs.writeFileSync('./lib/lock/whatanime.json', JSON.stringify(whatanimee))
				aruga.reply(from, 'تم فتح امر whatanime', id)
			} else if (args[0] == 'off') {
				let xporn = whatanimee.indexOf(chatId)
				whatanimee.splice(xporn, 1)
				fs.writeFileSync('./lib/lock/whatanime.json', JSON.stringify(whatanimee))
				aruga.reply(from, 'تم قفل امر whatanime', id)
			} else {
				aruga.reply(from, `Membuat BOT menyapa member yang baru join kedalam group chat!\n\nPenggunaan:\n${prefix}actwhatanime on --aktifkan\n${prefix}actwhatanime off --nonaktifkan`, id)
			}
            break
        case 'actship':
            if (!isGroupMsg) return aruga.reply(from, 'عذرًا ، لا يمكن استخدام هذا الأمر إلا داخل المجموعات!', id)
            if (!isGroupAdmins) return aruga.reply(from, 'عذراً ، لا يمكن استخدام هذا الأمر إلا من قبل مشرفين المجموعة!', id)
			if (args.length !== 1) return aruga.reply(from, `Membuat BOT menyapa member yang baru join kedalam group chat!\n\nPenggunaan:\n${prefix}actship --aktifkan\n${prefix}actship off --nonaktifkan`, id)
			if (args[0] == 'on') {
				ship.push(chatId)
				fs.writeFileSync('./lib/lock/ship.json', JSON.stringify(ship))
				aruga.reply(from, 'تم فتح امر ship', id)
			} else if (args[0] == 'off') {
				let xporn = ship.indexOf(chatId)
				ship.splice(xporn, 1)
				fs.writeFileSync('./lib/lock/ship.json', JSON.stringify(ship))
				aruga.reply(from, 'تم قفل امر ship', id)
			} else {
				aruga.reply(from, `Membuat BOT menyapa member yang baru join kedalam group chat!\n\nPenggunaan:\n${prefix}actwship on --aktifkan\n${prefix}actship off --nonaktifkan`, id)
			}
            break
        case 'acthentai':
            if (!isGroupMsg) return aruga.reply(from, 'عذرًا ، لا يمكن استخدام هذا الأمر إلا داخل المجموعات!', id)
            if (!isGroupAdmins) return aruga.reply(from, 'عذراً ، لا يمكن استخدام هذا الأمر إلا من قبل مشرفين المجموعة!', id)
			if (args.length !== 1) return aruga.reply(from, `Membuat BOT menyapa member yang baru join kedalam group chat!\n\nPenggunaan:\n${prefix}acthentai on --aktifkan\n${prefix}acthentai off --nonaktifkan`, id)
			if (args[0] == 'on') {
				hentai.push(chatId)
				fs.writeFileSync('./lib/lock/hentai.json', JSON.stringify(hentai))
				aruga.reply(from, 'تم فتح امر hentai', id)
			} else if (args[0] == 'off') {
				let xporn = hentai.indexOf(chatId)
				hentai.splice(xporn, 1)
				fs.writeFileSync('./lib/lock/hentai.json', JSON.stringify(hentai))
				aruga.reply(from, 'تم قفل امر hentai', id)
			} else {
				aruga.reply(from, `Membuat BOT menyapa member yang baru join kedalam group chat!\n\nPenggunaan:\n${prefix}acthentai on --aktifkan\n${prefix}acthentai off --nonaktifkan`, id)
			}
            break
        case 'acthentai_ownerbot':
            if (!isGroupMsg) return aruga.reply(from, 'عذرًا ، لا يمكن استخدام هذا الأمر إلا داخل المجموعات!', id)
            if (!isOwnerBot) return aruga.reply(from, 'عذراً . الامر خاص بمطور البوت!', id)
			if (args.length !== 1) return aruga.reply(from, `Membuat BOT menyapa member yang baru join kedalam group chat!\n\nPenggunaan:\n${prefix}acthentai on --aktifkan\n${prefix}acthentai off --nonaktifkan`, id)
			if (args[0] == 'on') {
				hentai.push(chatId)
				fs.writeFileSync('./lib/lock/hentai.json', JSON.stringify(hentai))
				aruga.reply(from, 'تم فتح امر hentai', id)
			} else if (args[0] == 'off') {
				let xporn = hentai.indexOf(chatId)
				hentai.splice(xporn, 1)
				fs.writeFileSync('./lib/lock/hentai.json', JSON.stringify(hentai))
				aruga.reply(from, 'تم قفل امر hentai', id)
			} else {
				aruga.reply(from, `Membuat BOT menyapa member yang baru join kedalam group chat!\n\nPenggunaan:\n${prefix}acthentai on --aktifkan\n${prefix}acthentai off --nonaktifkan`, id)
			}
            break
        case 'welcome':
			if (!isGroupMsg) return aruga.reply(from, 'Maaf, perintah ini hanya dapat dipakai didalam grup!', id)
            if (!isGroupAdmins) return aruga.reply(from, 'Gagal, perintah ini hanya dapat digunakan oleh admin grup!', id)
            if (!isBotGroupAdmins) return aruga.reply(from, 'Gagal, silahkan tambahkan bot sebagai admin grup!', id)
			if (args.length !== 1) return aruga.reply(from, `Membuat BOT menyapa member yang baru join kedalam group chat!\n\nPenggunaan:\n${prefix}welcome on --aktifkan\n${prefix}welcome off --nonaktifkan`, id)
			if (args[0] == 'on') {
				welcome.push(chatId)
				fs.writeFileSync('./lib/lock/welcome.json', JSON.stringify(welcome))
				aruga.reply(from, 'Welcome Message sekarang diaktifkan!', id)
			} else if (args[0] == 'off') {
				let xporn = welcome.indexOf(chatId)
				welcome.splice(xporn, 1)
				fs.writeFileSync('./lib/lock/welcome.json', JSON.stringify(welcome))
				aruga.reply(from, 'Welcome Message sekarang dinonaktifkan', id)
			} else {
				aruga.reply(from, `Membuat BOT menyapa member yang baru join kedalam group chat!\n\nPenggunaan:\n${prefix}welcome on --aktifkan\n${prefix}welcome off --nonaktifkan`, id)
			}
            break
            // Menu and TnC
        case 'antilink':
            if (!isGroupMsg) return aruga.reply(from, 'هذا الامر فقط بالقروب', id)
            if (!isGroupAdmins) return aruga.reply(from, 'هذا الامر فقط للمشرفين', id)
            if (!isBotGroupAdmins) return aruga.reply(from, 'اشرافي يسطا :)', id)
            if (args[0] == 'on') {
                var cek = antilink.includes(chatId);
                if(cek){
                    return aruga.reply(from, '*هذه الخاصيه فعاله بالفعل', id) //if number already exists on database
                } else {
                    antilink.push(chatId)
                    fs.writeFileSync('./lib/lock/antilink.json', JSON.stringify(antilink))
                    aruga.reply(from, '*كاشف الروابط الذكي]* \nاي شخص يرسل رابط قروب سيتم طرده !', id)
                }
            } else if (args[0] == 'off') {
                var cek = antilink.includes(chatId);
                if(!cek){
                    return aruga.reply(from, '*هذه الخاصيه غير فعاله بالفعل', id) //if number already exists on database
                } else {
                    let nixx = antilink.indexOf(chatId)
                    antilink.splice(nixx, 1)
                    fs.writeFileSync('./lib/lock/antilink.json', JSON.stringify(antilink))
                    aruga.reply(from, '*[كاشف الروابط]*تم اقفال هذه الميزه \n', id)
                }
            } else {
                aruga.reply(from, `pilih on / off\n\n*[Anti Group Link]*\nSetiap member grup yang mengirim pesan mengandung link grup akan di kick oleh bot!`, id)
            }
            break
            case 'pick':
            if (!isGroupMsg) return aruga.reply(from, 'عذرًا ، لا يمكن استخدام هذا الأمر إلا داخل المجموعات!', id)
        if (arguments.length < 1) return await aruga.reply(from, '_Contoh penggunaan perintah : !pick <sifat>_', id);
        const pickSomeone = groupMetadata.participants[Math.floor(Math.random() * groupMetadata.participants.length)];
        await aruga.sendTextWithMentions(from, `_👦🏼 ${arguments.join(' ')} في هاذا القروب @${pickSomeone.id.split('@')[0]}_`);
        break
        case 'sreddit':
            if (args.length == 0) return aruga.reply(from, `Untuk mencari gambar di sub reddit\nketik: ${prefix}sreddit [search]\ncontoh: ${prefix}sreddit naruto`, id)
            const carireddit = body.slice(9)
            const hasilreddit = await images.sreddit(carireddit)
            aruga.sendFileFromUrl(from, hasilreddit, '', '', id)
            .catch(() => {
                aruga.reply(from, 'هناك خطأ ما!', id)
            })
        default:
            console.log(color('[EROR]', 'red'), color(moment(t * 1000).format('DD/MM/YY HH:mm:ss'), 'yellow'), 'Unregistered Command from', color(pushname))
            if (args.length !== 1) return aruga.reply(from, 'باكا . الامر غير مدرج ', id)
            break
        }
    } catch (err) {
        console.log(color('[EROR]', 'red'), err)
    }
}
